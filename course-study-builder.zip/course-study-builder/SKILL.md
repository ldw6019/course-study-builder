---
name: course-study-builder
description: Gather and organize one course unit's class materials (lecture material required; practice material, the student's earlier questions, assignment or exam info optional), verify every checkable claim, and write the verified exam-prep summary as STUDY.md, then hand it to study-sheet-design for the Korean study PDF. Use when the student asks for 공부 자료, 복습 자료, 요약 정리, 정리본, 시험 대비 자료, 치트시트, a study guide or review sheet, or to sort a unit's class files. Not for re-typesetting an existing STUDY.md (study-sheet-design alone does that).
---

# Course study builder

This skill owns the **content**: it collects and sorts a unit's material, reads all of it, verifies what can be verified, and writes `STUDY.md`. It does not decide how anything looks. `study-sheet-design` turns `STUDY.md` into the PDF the student studies from.

The goal is not a prettier copy of the slides. It is a sheet the student can study from and test themselves with, in which every claim was either read from the source or checked.

| File | Use |
|---|---|
| `reference/format.md` | The `STUDY.md` contract (study/2). Read it before writing |
| `assets/STUDY.example.md` | A complete small example of every section and marker (shortened: real units need more cards and questions) |
| `scripts/check_study.py` | Validates `STUDY.md`: format errors and content warnings |

`STUDY.md` is machine-facing: the student never reads it. Its structure (tags, markers, keys) is English; everything that will be printed is Korean.

## 1. Inputs

| Input | Required? | What it is |
|---|---|---|
| A. Lecture material | **yes** | slides, lecture notes, textbook chapter, transcript (PDF, PPTX, DOCX, MD, text, images) |
| B. Practice material | no | labs, example code, problem sets, datasets, worked solutions |
| C. Student Q&A / notes | no | questions the student asked in earlier chats, own notes, TA answers |
| D. Assignment / exam info | no | assignment guide, grading rules, exam scope, past exam style |

Ask only for A if it is missing. Use B, C, D when given; never block on them, and say in the report which existed.

Settle once (defaults in brackets): exam scope [all of A]; answers in the card or collected at the back [`inline`]; course name and term for the cover [from file names or slides, otherwise leave out rather than guess]; an unfinished assignment is explained, never solved.

## 2. Workflow

1. **Intake.** List what was received, the unit, the scope, anything unreadable. Ask at most one short question, and only if the answer changes the work.
2. **Organize the unit folder** (section 7). Skip when the material is only chat uploads.
3. **Read everything.** Every page of A, all of B (section 6). Note pages that were image-only or unreadable.
4. **Map.** Privately: page range → topic; which pages are diagrams only; which examples exist in B; where slides and practice material disagree.
5. **Mine C.** The student's own questions show exactly where they got stuck. Keep the question, a corrected short answer, and its date.
6. **Verify** (section 5). Collect only observed results.
7. **Write `_study/STUDY.md`** per `reference/format.md`, section by section with file tools (avoids truncated output). Decide the card and question counts first (3.2), then write every planned item in full.
8. **Check.** `python <this skill>/scripts/check_study.py <unit>/_study/STUDY.md`. Fix every ERROR. Fix every WARN or keep a one-line reason for the report.
9. **Hand off.** Load `study-sheet-design` with the Skill tool and follow it: it draws the figures and builds the PDF. If it cannot run (no browser even after its install step), deliver `STUDY.md` and its HTML fallback and say so.
10. **Report** briefly, result first: PDF and `STUDY.md` paths, page count, sources used (and which of B, C, D did not exist), what was verified or corrected, what was left out and why, any remaining warnings. Answers in Korean.

If a file is too large, unreadable, or unsupported, report which pages were read and which were not. Never imply full coverage.

## 3. What goes on the sheet

### 3.1 Sections

In order: `[map]` (the whole unit as a tree, page on every line) → one topic section per source topic, in source order → `[summary]` cheat sheet (formulas, commands, definitions, comparison tables) → `[labs]` (only if B exists: item, pages, status) → `[think]` self-test cards → `[review]` questions. Exact syntax: `reference/format.md`.

### 3.2 Counts

Default **8~9 cards** and **about 20 review questions**. Scale both to the unit: fewer for a short or thin unit, never padded with weak or repetitive items. Every planned item is written in full. A count below the default goes in the report.

### 3.3 A topic section

In this order, skipping what does not apply:
1. The core idea in one or two sentences, most important first: the first sentence becomes the section's lead line.
2. First use of a term: Korean term plus the original, e.g. 파일 디스크립터(file descriptor, fd).
3. A `figure` block for architectures, memory layouts, flows, hierarchies, timelines: the structure as ASCII plus every label and number the drawing needs.
4. Definition, signature or formula, with return values or conditions (`[!formula]` for the one formula to memorize).
5. A table for options, cases, or A-versus-B.
6. The source example (A or B), cut to the lines that matter.
7. The observed output in an `out` block.
8. `[!warn]` for slide mistakes, traps, surprises; `[!note]` for the student's own questions (C); `[!key]` for exam signals (4.3).

Break complex ideas into tables, lists and figures rather than long paragraphs.

### 3.4 Self-test cards

The point is to make the student **predict and explain**, not just recall. Each card: a runnable snippet, scenario or calculation; prediction questions; a one-line hint that points at a page or concept, never the answer; an answer that opens with the observed or computed result in one bold sentence, then the output or working, then why, then where it matters.

Mix the types, inside this unit's material: predict before running (a small change to a source example) · discover by experiment (implied but never shown) · edge cases (errors, empty input, limits, units, boundaries) · find the bug (a plausible wrong version) · design it (one open question, `[discuss]` card: the verdict states the deciding criterion, then a 선택지 | 맞는 경우 | 비용 table). Link cards to each other and to the assignment when it helps. For non-programming subjects "run it" becomes "work it out": changed numbers, a case to classify, an argument to critique, a proof step to justify, a graph to read.

### 3.5 Review questions

One fact or one explanation per row; answer in one to three sentences ending with `(p.N)`. Weight toward what the exam is likely to test **according to the sources**:
- If D shows the exam's question style (객관식, 단답, 서술, 계산, 코드 해석 or 출력 예측), write in that style and say so in the report. Use actual past questions only as a style model; never copy them or present any question as an exam question.
- Cover every `[!key]` exam signal with at least one question or card.
- Without D, mix recall (definitions, rules) with application (compute a value, predict an output).

## 4. Writing rules

### 4.1 Style

Short sentences, result first. Tables for comparisons. `**bold**` for one key phrase per paragraph, never whole sentences. No emojis, no filler. Code, commands, formulas and error messages exactly as they are, in backticks or code blocks. Mark source mistakes explicitly and say what the sheet changed.

### 4.2 Honesty

- **Never invent facts.** If the material is silent, write 자료에 없음; mark any addition `(보충: 강의자료 밖 내용)`.
- **Never present self-made questions as official exam questions.**
- Label anything unchecked `(미검증, …)`. If an earlier chat answer (C) turns out wrong, write the observed behavior and tell the student about the correction.
- Image-only pages: describe them from the surrounding pages and say the page was image-only.
- Name the environment when results depend on it (compiler, version, locale, calculator mode); put it in front matter `env`.

### 4.3 Exam scope and signals

If the student states a scope ("up to p.41"): put the in-scope range in `scope` and a one-sentence `scope_note`; keep the excluded part as an `[oos]` section (still useful); write no cards for it unless the card is really about an in-scope idea; record the scope where the next session will see it (a note file in the unit folder or the project instructions).

When A or D itself marks something as exam-relevant (the lecturer says it will be on the exam, a slide says 중요 or 시험, the exam notice names a topic), add `[!key]` at that spot with the source, e.g. `강의에서 시험 출제를 언급함 (p.23)`. Mark only what the sources mark; your own guess about likely exam topics goes in the report, labelled as your opinion. If there are no signals, say so in one line of the report.

## 5. Verification

| Material | How |
|---|---|
| Executable code | Build and run in a throwaway directory. Quote real output; test at least one edge case or error |
| Math, statistics, numbers | Recompute worked examples programmatically or step by step. Check units, rounding, boundaries |
| Commands, configs, system calls | Local sandbox, dry-run flags, mock mode or help output. **Never modify live system state or run paid operations** |
| Definitions, theorems, models | Cross-check against the lecture text; flag ambiguities and discrepancies |
| Not verifiable | Reason through it, then mark `(미검증, 직접 실행해 보지 못함)` |

Use only output you actually saw; do not tidy it. Temporary files only, deleted afterwards; never run anything inside the student's assignment folders. If a verified result contradicts the lecture, report both and explain.

## 6. Reading awkward inputs

| Input | How |
|---|---|
| Text PDF | PyMuPDF (`pip install pymupdf`, `page.get_text()` per page), keeping page numbers. `pdftotext -layout` can scramble slide code that mixes Korean and code; if code looks broken, re-extract that page or look at its image, and never copy broken code |
| Image-only slides, scans | Look at the page images; OCR if available; otherwise ask for the text of those pages |
| PPTX / DOCX | Convert to PDF or text first, keeping slide numbers |
| Notebooks | Read cell by cell; run if the environment allows |
| Code folders | List, read each file, run the tests or build step if there is one |
| Chat exports | Pick this unit's questions; keep the student's wording |

If a tool is missing and cannot be installed, ask for the text of the needed pages. Do not guess page contents.

## 7. Organizing the unit folder

Target layout (adapt to a structure the student already uses instead of forcing this one):

```
<course>/<NN_topic>/            e.g. 07_예외처리
  강의/      A: slides, notes, transcripts
  실습/      B: labs, example code, data
  과제/      D: assignment guides, exam notices
  메모/      C: the student's questions and notes
  _study/    STUDY.md and figures (machine files, made by the two skills)
  7주차_공부자료(예외 처리).pdf
```

Rules:
- Show the plan first as a table (current path → new path) and wait for the student's OK. If nobody is there to answer, do not move anything: write `_study/` only and put the plan in the report.
- Move and rename only. Never delete, never overwrite (add a suffix on a name clash), never edit a file's contents. Keep original file names unless the student asks for renaming.
- Touch only files the student pointed at or that are already in the unit folder.
- If the files are not reachable (chat uploads only), skip this step; `_study/` and the PDF are delivered as files.

## 8. Final checklist

Only what the script cannot judge:
- [ ] Every page of A is covered in source order, or the report says which pages were not read
- [ ] Every example result or number was observed or recomputed, or is marked `(미검증, …)`
- [ ] Source mistakes are flagged with `[!warn]`; corrected earlier answers (C) are flagged and told to the student
- [ ] Exam signals come from the sources only, each covered by a card or question
- [ ] If D gave a question style, the review questions follow it
- [ ] Open assignments are explained, not solved
- [ ] Printed text is Korean (code, commands, formulas excepted)
- [ ] `check_study.py` shows no ERROR; every WARN fixed or explained
- [ ] Folder moves were confirmed; nothing deleted or overwritten; temporary files removed
