# STUDY.md format (study/2)

`STUDY.md` is a machine handoff file. `study-sheet-design` parses it and typesets the PDF the student reads. The student never reads `STUDY.md`, so optimize it for exact parsing, not for looks. A full example is `assets/STUDY.template.md`.

Two rules decide everything else:
- **Structure is English, content is Korean.** Tags, markers and front-matter keys are fixed English tokens. Every sentence, title, table cell and label that will be printed is in Korean (code, commands, formulas and error messages stay as they are).
- **Only what is listed here.** No raw HTML, no images, no links, no italics, no nested lists. Anything else prints as plain text or breaks the parse.

`scripts/check_study.py STUDY.md` validates all of this.

## Front matter

The file starts with a `---` block of `key: value` lines (one line per value, no quotes needed).

| Key | Required | Printed as | Example |
|---|---|---|---|
| `format` | yes | – | `study/2` |
| `unit` | yes | big unit number on the cover, footer | `7` |
| `topic` | yes | cover title, footer, PDF name | `예외 처리` |
| `sources` | yes | cover "출처" | `` `07-예외처리.pdf` p.1~16, 실습 `lab/ex1_divide.py` `` |
| `course` | no | cover top left | `프로그래밍 기초 (파이썬)` |
| `term` | no | cover top right | `2026-2 중간고사` |
| `subject` | no | picks the accent color | `programming` (see below) |
| `subtitle` | no | one-line summary under the title | `오류는 처리할 수 있는 자리에서, 구체적인 이름으로 잡는다` |
| `scope` | no | cover "범위" (in-scope pages) | `p.1~14` |
| `scope_note` | no | warning line on the cover | `시험범위는 p.1~14다. p.15~16은 따로 둔다.` |
| `env` | no | cover "검증" (where outputs were observed) | `Python 3.13.17` |
| `answers` | no | `inline` (default) or `appendix` | `inline` |
| `accent` | no | overrides `subject` | `#2b44b8` |

`subject` values: `programming`, `engineering`, `math`, `physics` (navy) · `biology`, `chemistry`, `earth-science` (teal) · `humanities`, `language`, `arts`, `history`, `philosophy` (plum) · `economics`, `business`, `social` (ochre). Anything else gets navy.

## Sections

Every `##` heading starts a section. Its kind is set by a tag at the start of the heading, not by its wording.

| Heading | Kind | Contents |
|---|---|---|
| `## [map]` | one-page summary (cover) | exactly one code block: a tree, `(p.N)` or `(p.A~B)` on every line, `[oos]` before out-of-scope nodes |
| `## <title> (p.A~B)` | topic | blocks below; page reference required |
| `## [oos] <title> (p.A~B)` | topic outside the exam scope | same; do not add a scope warning inside, the tag prints it |
| `## [summary] <title>` | cheat sheet | tables of formulas, commands, definitions |
| `## [labs] <title>` | practice material status | one table: item, related pages, status. Only if practice material exists |
| `## [think]` | self-test cards | `###` cards only (below). No intro text: the design prints the routine |
| `## [review]` | review questions | one two-column table `Q`, `A`. No intro text |

Order: `[map]`, topics in source order, `[summary]`, `[labs]`, `[think]`, `[review]`. Do not number topic titles; the design numbers them.

## Blocks (inside topic, summary, labs sections)

| Write | Prints as |
|---|---|
| paragraph | body text. The **first sentence of the first paragraph** becomes the section's lead line, so make it the core idea |
| `\| a \| b \|` table | booktabs table. A first cell written as `` `code` `` alone becomes a key column |
| `- item` / `1. item` | flat list |
| ```` ```lang ```` code | code block. Lines starting with `$ ` print as a terminal |
| ```` ```out ```` | observed output, labelled 실행 결과. Copy exactly what was seen |
| ```` ```figure <id> <caption> ```` | a figure. Body: the structure as ASCII plus every label and number the drawing needs. `id` is `[a-z0-9-]+`, unique; caption is Korean. The design draws it as `figures/<id>.svg` |
| `### <label>` | small label above the next block |
| `> [!warn] text` | warning (주의). Traps, slide mistakes |
| `> [!note] text` | note (참고). The student's own earlier questions, with their date |
| `> [!key] text` | key point (핵심). Exam signals from the sources, with the page |
| `> [!hint] text` | hint line (in cards) |
| `> [!formula]` + lines `> lhs = rhs`, optional last line `> ex: text` | numbered display formula, at most one per section |

Inline: `` `code` ``, `**bold**` (one key phrase per paragraph), `(p.N)` / `(p.A~B)`, `(보충: …)` for content outside the material, `(미검증, …)` for anything not checked. Both parenthesized marks also put a note in the margin.

Write warnings and notes as long as they need to be; the design decides margin note vs. body paragraph.

## Cards (inside `## [think]`)

```
### <question title> (p.A~B)
<setup: code block, scenario paragraph, or table the student can actually run or work through>

[[predict]]
- <prediction question 1?>
- <prediction question 2?>

> [!hint] <one line pointing at a page or concept, never the answer>

[[answer]]
**<The observed or computed result, one sentence.>**

<```out block if there is one, then why, then what it teaches>
[[/answer]]
```

- Add ` [discuss]` at the end of the heading for an open design question. Its verdict line states the deciding criterion, not a winner, followed by a table `선택지 | 맞는 경우 | 비용`.
- Cards are numbered by the design in order; do not number them.
- Exactly one `[[predict]]` and one `[[answer]] … [[/answer]]` per card. The list right after `[[predict]]` becomes the prediction questions.

## Review table (inside `## [review]`)

```
| Q | A |
|---|---|
| <one fact or one explanation> | <one to three sentences> (p.N). |
```

## Files next to STUDY.md

```
<unit folder>/
  _study/STUDY.md
  _study/figures/<id>.svg      drawn by study-sheet-design
  N주차_공부자료(Topic).pdf     written by study-sheet-design
```
