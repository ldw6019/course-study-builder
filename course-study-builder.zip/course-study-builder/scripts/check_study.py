#!/usr/bin/env python3
"""Validate a STUDY.md (study/2) before handing it to study-sheet-design.

  python check_study.py <unit>/_study/STUDY.md

ERROR lines break the handoff (the design build would fail or misprint); fix all of them.
WARN lines are content rules from SKILL.md; fix them or say in the report why not.
Exit status 1 if there is any ERROR. Standard library only.
"""
import re
import sys
from pathlib import Path

KEYS = {"format", "unit", "topic", "sources", "course", "term", "subject", "subtitle",
        "scope", "scope_note", "env", "answers", "accent"}
REQUIRED = ("format", "unit", "topic", "sources")
SUBJECTS = {"programming", "engineering", "math", "physics", "cs", "biology", "chemistry",
            "earth-science", "life-science", "humanities", "language", "arts", "history",
            "philosophy", "literature", "economics", "business", "social"}
TAGS = {"map", "summary", "labs", "think", "review", "oos"}
CALLOUTS = {"warn", "key", "note", "hint", "formula"}
PAGE = re.compile(r"\(p\.\s?(\d+)(?:\s?[~–-]\s?(\d+))?(?:,\s*p\.\s?\d+(?:\s?[~–-]\s?\d+)?)*\)")
LEGACY = re.compile(r"^>\s*\*\*(주의|핵심|참고|힌트|Warning|Key|Note|Hint)\*\*\s*:|\[\[/?(예측|정답|Predict|Answer)\]\]|^###\s+(생각|Think)\s*\d")


def main(path):
    text = Path(path).read_text(encoding="utf-8")
    lines = text.splitlines()
    errors, warns = [], []
    E = lambda n, m: errors.append((n, m))
    W = lambda n, m: warns.append((n, m))

    # front matter
    meta, body_start = {}, 0
    if not lines or lines[0].strip() != "---":
        E(1, "file must start with a '---' front matter block")
    else:
        for i in range(1, len(lines)):
            s = lines[i].strip()
            if s == "---":
                body_start = i + 1
                break
            if not s:
                continue
            k, sep, v = s.partition(":")
            if not sep:
                E(i + 1, "front matter line is not 'key: value'")
                continue
            k = k.strip()
            if k not in KEYS:
                W(i + 1, "unknown front matter key %r (ignored by the design)" % k)
            meta[k] = v.strip()
        else:
            E(1, "front matter is not closed with '---'")
    for k in REQUIRED:
        if not meta.get(k):
            E(1, "front matter needs %s" % k)
    if meta.get("format") and meta["format"] != "study/2":
        E(1, "format must be study/2")
    if meta.get("answers") and meta["answers"] not in ("inline", "appendix"):
        E(1, "answers must be inline or appendix")
    if meta.get("subject") and meta["subject"].lower() not in SUBJECTS:
        W(1, "subject %r is not in the list; the accent falls back to navy" % meta["subject"])
    if meta.get("accent") and not re.fullmatch(r"#[0-9a-fA-F]{6}", meta["accent"]):
        E(1, "accent must look like #2b44b8")
    if meta.get("unit") and not re.fullmatch(r"\d+", meta["unit"]):
        W(1, "unit should be a number (it prints as the big cover number)")

    # sections
    secs, cur, fence = [], None, False
    for n in range(body_start, len(lines)):
        line = lines[n]
        s = line.strip()
        if s.startswith(("```", "~~~")):
            fence = not fence
            if cur is not None:
                cur["lines"].append((n + 1, line))
            continue
        if not fence and line.startswith("## "):
            title = line[3:].strip()
            m = re.match(r"^\[([a-z-]+)\]\s*", title)
            tag = m.group(1) if m else ""
            if tag and tag not in TAGS:
                E(n + 1, "unknown section tag [%s]" % tag)
            cur = {"n": n + 1, "tag": tag or "topic", "title": title[m.end():] if m else title, "lines": []}
            secs.append(cur)
            continue
        if cur is None:
            if s:
                E(n + 1, "content before the first ## section")
            continue
        cur["lines"].append((n + 1, line))
        if fence:
            continue
        if LEGACY.search(s):
            E(n + 1, "old (v1) marker; use > [!warn] / [[predict]] / [[answer]] / plain ### card titles")
        if re.search(r"<(svg|div|span|br|img|a|p|table|details)\b", s):
            E(n + 1, "raw HTML is not allowed")
        m = re.match(r"^>\s*\[!([a-z]+)\]", s)
        if m and m.group(1) not in CALLOUTS:
            E(n + 1, "unknown callout [!%s]" % m.group(1))
        elif s.startswith(">") and not m and not cur.get("in_quote"):
            W(n + 1, "untagged quote prints as a note; use > [!warn] / [!note] / [!key] / [!hint]")
        cur["in_quote"] = s.startswith(">")
        if re.match(r"^\s{2,}[-*]\s|^\s{2,}\d+\.\s", line):
            W(n + 1, "nested list; lists must be flat")
        if re.match(r"^\[\[/?(predict|answer)\]\]$", s) and cur["tag"] != "think":
            E(n + 1, "%s outside ## [think]" % s)
        if re.search(r"!\[[^\]]*\]\(|\[[^\]]+\]\(https?://", s):
            E(n + 1, "images and links are not allowed")
        if re.search(r"(?<![*\w])_[^_\s][^_]*_(?![\w])|(?<![*])\*[^*\s][^*]*\*(?![*])", re.sub(r"`[^`]*`", "", s)):
            W(n + 1, "italics are not supported")
        if re.sub(r"`[^`]*`", "", s).count("**") % 2:
            E(n + 1, "unbalanced ** (bold would not close)")
    if fence:
        E(len(lines), "unclosed code fence")

    tags = [s["tag"] for s in secs]
    for t in ("map", "think", "review"):
        c = tags.count(t)
        if c == 0:
            E(1, "missing ## [%s] section" % t)
        elif c > 1:
            E(1, "more than one ## [%s] section" % t)
    if tags.count("summary") > 1:
        W(1, "more than one [summary] section")

    fig_ids = {}
    oos_pages = set()
    for s in secs:
        if s["tag"] == "oos":
            m = PAGE.search(s["title"])
            if m:
                a, b = int(m.group(1)), int(m.group(2) or m.group(1))
                oos_pages |= set(range(a, b + 1))
    for s in secs:
        tag, body = s["tag"], s["lines"]
        if tag in ("topic", "oos"):
            if not PAGE.search(s["title"]):
                E(s["n"], "topic heading needs a page reference (p.A~B)")
            if re.match(r"^\d+[.)]\s", s["title"]):
                W(s["n"], "do not number topic titles; the design numbers them")
            if tag == "oos" and any(re.search(r"시험\s*범위", l) for _, l in body if l.strip().startswith(">")):
                W(s["n"], "no scope warning inside an [oos] section; the tag prints it")
            if not any(l.strip() and not l.strip().startswith(("|", ">", "```", "#", "-", "[[")) for _, l in body):
                W(s["n"], "no paragraph: the first sentence of the first paragraph is the section's lead line")
            if sum(1 for _, l in body if re.match(r"^>\s*\[!formula\]", l.strip())) > 1:
                W(s["n"], "more than one [!formula] in a section")
        if tag == "map":
            code = []
            inside = False
            for n, l in body:
                if l.strip().startswith("```"):
                    inside = not inside
                    continue
                if inside and l.strip():
                    code.append((n, l))
            if not code:
                E(s["n"], "[map] needs one code block with the tree")
            for n, l in code:
                if not PAGE.search(l):
                    W(n, "map line without (p.N)")
        if tag == "review":
            rows = [l.strip() for _, l in body if l.strip().startswith("|")]
            rows = [r for r in rows if not re.fullmatch(r"\|[\s:|-]+\|?", r)]
            if not rows:
                E(s["n"], "[review] needs a | Q | A | table")
            else:
                cols = len(rows[0].strip("|").split("|"))
                if cols != 2:
                    E(s["n"], "review table must have two columns: Q, A")
                n_rows = len(rows) - 1
                if n_rows < 15:
                    W(s["n"], "%d review rows; default is about 20 (fine for a short unit, say so in the report)" % n_rows)
                elif n_rows > 30:
                    W(s["n"], "%d review rows; check none are padding" % n_rows)
                for r in rows[1:]:
                    if not PAGE.search(r):
                        W(s["n"], "review answer without (p.N): %s" % r[:50])
            if any(l.strip() and not l.strip().startswith("|") for _, l in body):
                W(s["n"], "text outside the table in [review] is not printed")
        if tag == "think":
            cards, cur = [], None
            for n, l in body:
                if l.startswith("### "):
                    cur = {"n": n, "title": l[4:].strip(), "lines": []}
                    cards.append(cur)
                elif cur is None and l.strip():
                    W(n, "text before the first card in [think] is not printed")
                elif cur is not None:
                    cur["lines"].append((n, l))
            if not cards:
                E(s["n"], "[think] has no ### cards")
            elif len(cards) < 5:
                W(s["n"], "%d cards; default is 8~9 (fine for a short unit, say so in the report)" % len(cards))
            elif len(cards) > 12:
                W(s["n"], "%d cards; check none are padding" % len(cards))
            for c in cards:
                seq = [l.strip() for _, l in c["lines"] if re.match(r"^\[\[/?(predict|answer)\]\]$", l.strip())]
                if seq != ["[[predict]]", "[[answer]]", "[[/answer]]"]:
                    E(c["n"], "card needs exactly [[predict]], [[answer]], [[/answer]] in that order (found %s)" % (seq or "none"))
                    continue
                if not PAGE.search(c["title"]):
                    W(c["n"], "card title without (p.N)")
                if re.match(r"^\d+[.)]\s", c["title"]):
                    W(c["n"], "do not number cards; the design numbers them")
                ls = [l for _, l in c["lines"]]
                ip = next(i for i, l in enumerate(ls) if l.strip() == "[[predict]]")
                ia = next(i for i, l in enumerate(ls) if l.strip() == "[[answer]]")
                nxt = next((l.strip() for l in ls[ip + 1:] if l.strip()), "")
                if not re.match(r"^(-|\d+\.)\s", nxt):
                    W(c["n"], "no prediction questions: put a - list right after [[predict]]")
                if not any(re.match(r"^>\s*\[!hint\]", l.strip()) for l in ls[:ia]):
                    W(c["n"], "card without a > [!hint] line")
                first = next((l.strip() for l in ls[ia + 1:] if l.strip()), "")
                if not re.fullmatch(r"\*\*.+\*\*", first):
                    W(c["n"], "answer should open with a **bold verdict sentence**")
                if "[discuss]" in c["title"] and not any(l.strip().startswith("|") for l in ls[ia:]):
                    W(c["n"], "[discuss] card: add the 선택지 | 맞는 경우 | 비용 table")
                m = PAGE.search(c["title"])
                if m and oos_pages:
                    a, b = int(m.group(1)), int(m.group(2) or m.group(1))
                    if set(range(a, b + 1)) <= oos_pages:
                        W(c["n"], "card is only about out-of-scope pages")
        for n, l in body:
            m = re.match(r"^\s*```figure\b(.*)$", l)
            if m:
                mm = re.match(r"^\s+([a-z0-9-]+)\s+(\S.*)$", m.group(1))
                if not mm:
                    E(n, "figure block needs an id and a caption: ```figure <id> <caption>")
                    continue
                if mm.group(1) == "cover":
                    E(n, "figure id 'cover' is reserved for the cover motif")
                if mm.group(1) in fig_ids:
                    E(n, "figure id %r used twice (first at line %d)" % (mm.group(1), fig_ids[mm.group(1)]))
                fig_ids[mm.group(1)] = n
        if tag in ("topic", "oos", "summary", "labs") and not body:
            W(s["n"], "empty section")

    for n, m in errors:
        print("ERROR line %d: %s" % (n, m))
    for n, m in warns:
        print("WARN  line %d: %s" % (n, m))
    print("check: %d error(s), %d warning(s)" % (len(errors), len(warns)))
    return 1 if errors else 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    sys.exit(main(sys.argv[1]))
