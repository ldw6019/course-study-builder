---
name: study-sheet-design
description: "Typesets a finished STUDY.md (format study/2, written by course-study-builder) into the established Korean textbook-style A4 study PDF: serif body, margin notes, exam-paper self-test cards, fold-to-hide review table. Draws the figures the sheet asks for, then builds and checks the PDF with one command. Use at the end of course-study-builder, or when the student asks to re-render, redesign, 예쁘게, or 디자인 an existing study sheet. Not for writing, researching or verifying study content."
---

# Study sheet design

역할은 **조판**이다. `course-study-builder`가 쓴 `STUDY.md`(내용)를 받아, 이미 정해 둔 디자인으로 PDF를 만든다. 내용(값, 쪽 번호, 실행 결과, 문장)은 바꾸지 않는다. 이 스킬이 손으로 만드는 것은 **그림 SVG**뿐이고, 나머지는 `build.py`가 자동으로 조판한다.

```
study-sheet-design/
  SKILL.md                 이 파일: 순서, 점검표
  scripts/build.py         STUDY.md → HTML → PDF → 차례 쪽 번호 맞춤 → 점검 → 미리보기 (이것 하나만 실행)
  scripts/sheet.py         STUDY.md 해석과 HTML 조립 (build.py가 불러 씀)
  reference/svg.md         그림 그릴 때 읽는다: 팔레트, 패턴, 스니펫
  reference/design.md      판면, 색·글꼴 원칙, 금지 패턴, STUDY.md → 컴포넌트 대응표 (CSS를 고칠 때)
  reference/components.md  HTML 부품 목록 (sheet.py나 CSS를 고칠 때)
  assets/study.css         디자인 토큰과 컴포넌트 스타일
  assets/defs.svg          공용 화살표·빗금
  assets/fonts/            Noto Serif KR, Pretendard, JetBrains Mono (오프라인 렌더)
```

입력은 `<단원 폴더>/_study/STUDY.md`다. 형식은 course-study-builder의 `reference/format.md`가 정한다. 형식이 틀리면 build가 어디가 틀렸는지 말하고 멈춘다. 그때는 STUDY.md를 고친다(course-study-builder의 `check_study.py`로 확인).

## 순서

1. **브라우저 확인**: `python "<이 스킬 폴더>/scripts/build.py" --check`. 경로가 나오면 다음으로. 못 찾으면 한 번만 설치한다: `pip install playwright && python -m playwright install chromium`. 그래도 안 되면 `build.py STUDY.md --html-only`로 HTML을 만들어 주고, 브라우저에서 A4·배경 그래픽 켜고 인쇄하라고 한 줄로 알린다. 점검(쪽 번호, 대비 등)에는 PyMuPDF가 필요하다: `pip install pymupdf`.
2. **첫 빌드**: `python "<이 스킬 폴더>/scripts/build.py" "<단원>/_study/STUDY.md" --preview "<스크래치>/preview"`. 출력의 `그림 없음:` 목록이 그려야 할 그림이다.
3. **그림 그리기**: 목록의 id마다 `_study/figures/<id>.svg`를 쓴다. 먼저 `reference/svg.md`를 읽는다. STUDY.md의 figure 블록이 내용이다. 그 구조, 라벨, 숫자만 그림으로 옮기고 새 사실을 더하지 않는다. 어울리면 표지 모티프 `figures/cover.svg`를 그린다(선택, 단원 내용을 추상화한 것만).
4. **다시 빌드**하고 출력의 경고를 모두 없앤다.
   - `그림 규칙:` 폭 540, 루트 font-family의 Pretendard, width/height 속성 없음
   - `대비 부족:` 글자색과 바탕색 대비. 그림이면 svg.md 팔레트로 고친다
   - `대체 글꼴 사용:` 그림의 font-family나 기호를 고친다. 본문 기호면 STUDY.md의 기호를 바꿀 수 있는지 course 쪽 규칙으로 판단한다
   - `쪽 끝 제목:`, 거의 빈 쪽: 그림을 낮게 그린다. 그래도 남으면 그대로 두고 보고에서 알린다(내용을 빼서 맞추지 않는다)
5. **미리보기 보기**: 아래 점검표로 확인한다. 긴 자료는 표지, 그림이 있는 쪽, 카드 쪽, 복습 쪽, 마지막 쪽을 먼저 보고 나머지는 훑는다.
6. **마무리**: 단원 폴더에는 PDF, `_study/`에는 STUDY.md, `figures/`, `sheet.html`(조판 결과, 손대지 않음)이 남는다. 미리보기는 스크래치 폴더에 둔다. 보고는 짧게: PDF 경로, 쪽수, 강조색, 그린 그림, 남은 경고와 이유.

`--answers appendix`는 front matter의 `answers`보다 우선한다. 강조색은 front matter의 `subject`로 정해진다(`accent`로 직접 지정 가능, 흰 바탕과 대비가 낮으면 build가 어둡게 고친다).

## 무엇을 어디서 고치나

| 문제 | 고치는 곳 |
|---|---|
| 내용, 쪽 번호, 실행 결과, 문장 | `STUDY.md` (course-study-builder 규칙대로) |
| 그림 | `_study/figures/<id>.svg` |
| 모양 전체(간격, 글꼴, 색) | `assets/study.css`와 `sheet.py`. `reference/design.md`의 원칙과 금지 패턴을 지킨다. 디자인은 확정된 것이라 학생이 요청할 때만 바꾼다 |
| `sheet.html` | 고치지 않는다. 다음 빌드에서 덮어쓴다 |

## 렌더 점검표

build 출력:
- [ ] `그림: 모두 있음` (또는 `그림: 없음`), `그림 규칙:` 줄이 없다
- [ ] `차례: 쪽 번호가 실제와 맞다`
- [ ] `대비: 모든 글자가 WCAG AA 기준을 넘는다`
- [ ] `글꼴: Pretendard / JetBrains Mono / Noto Serif KR만 사용`
- [ ] `쪽 끝 제목:` 경고가 없다

미리보기:
- [ ] 절반 넘게 빈 쪽이 없다 (마지막 쪽과 정답 부록 앞쪽은 예외)
- [ ] 카드, 표의 행, 그림, 코드가 쪽 경계에서 잘리지 않았다
- [ ] 날개 메모가 해당 본문 옆에 있다
- [ ] SVG 글자가 상자 밖으로 나가거나 겹치지 않았다. 코드 줄이 잘리지 않았다
- [ ] 그림 속 숫자와 라벨이 STUDY.md의 figure 블록과 같다
- [ ] 시험범위 밖 내용이 표지 맵, 차례, 섹션 머리 세 곳에서 모두 구분된다
- [ ] 정답 부록 모드라면 카드 안에 정답이 없다
- [ ] 꼬리말은 2쪽부터 나온다 (표지에는 일부러 없다)

## 환경

- Edge, Chrome, Chromium 중 하나가 필요하다. Playwright가 받아 둔 Chromium(`PLAYWRIGHT_BROWSERS_PATH`, `~/.cache/ms-playwright` 등)도 자동으로 찾는다. 못 찾으면 `STUDY_BROWSER` 환경변수에 실행 파일 경로를 넣는다. Chrome 131 이상이어야 `@page` 꼬리말이 나온다.
- Linux에서 root로 실행하면 `--no-sandbox`를 자동으로 붙인다. 필요하면 `STUDY_NO_SANDBOX=1`.
- 글꼴은 모두 `assets/fonts`에 있다. Noto Serif KR은 현대 한글 11,172자와 라틴·문장부호만 담은 서브셋이라, 한자·옛한글·일부 기호(`°` 등)는 대체 글꼴로 찍힌다. build가 알려 준다.
- 흑백 인쇄용이면 `pre.term`을 밝은 `pre`로 바꿔 토너를 아낀다(CSS).
