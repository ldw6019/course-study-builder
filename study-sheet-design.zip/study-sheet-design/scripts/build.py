#!/usr/bin/env python3
"""study-sheet-design: STUDY.md -> PDF 한 번에.

  python build.py <단원>/_study/STUDY.md            # PDF + 점검 + 미리보기
  python build.py STUDY.md --answers appendix         # 정답을 맨 뒤 부록으로
  python build.py STUDY.md --preview <스크래치>/preview
  python build.py STUDY.md --html-only                # 브라우저가 없을 때: HTML만
  python build.py --check                             # 브라우저만 찾아 보고 끝낸다

하는 일: STUDY.md 해석(sheet.py) -> HTML -> Chromium 인쇄 -> 차례 쪽 번호 맞춤(다시 인쇄)
-> 점검(그림, 쪽 끝 제목, 빈 쪽, 대체 글꼴, 글자 대비) -> 미리보기 PNG.
출력: PDF는 단원 폴더(_study의 부모)에 N주차_공부자료(Topic).pdf, 조판 HTML은 _study/sheet.html.
HTML은 산출물이다. 고칠 것은 STUDY.md(내용)나 figures/<id>.svg(그림)에서 고치고 다시 빌드한다.
"""
import argparse
import html as htmlmod
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile

SKILL = pathlib.Path(__file__).resolve().parent.parent
ASSETS = SKILL / "assets"
EXPECTED_FONTS = ("Pretendard", "JetBrainsMono", "NotoSerifKR")

BROWSER_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
]
BROWSER_NAMES = ["google-chrome", "chromium", "chromium-browser", "microsoft-edge", "msedge", "chrome"]
# Playwright가 받아 둔 Chromium (클라우드·CI 환경에서 흔하다)
PW_PATTERNS = [
    "chromium-*/chrome-linux*/chrome",
    "chromium-*/chrome-win*/chrome.exe",
    "chromium-*/chrome-mac*/Chromium.app/Contents/MacOS/Chromium",
    "chromium-*/chrome-mac*/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing",
]


def playwright_browsers():
    roots = []
    env = os.environ.get("PLAYWRIGHT_BROWSERS_PATH")
    if env and env != "0":
        roots.append(pathlib.Path(env))
    home = pathlib.Path.home()
    roots += [home / ".cache" / "ms-playwright", home / "Library" / "Caches" / "ms-playwright"]
    if os.environ.get("LOCALAPPDATA"):
        roots.append(pathlib.Path(os.environ["LOCALAPPDATA"]) / "ms-playwright")
    found = []
    for r in roots:
        if r.is_dir():
            for pat in PW_PATTERNS:
                found += [p for p in r.glob(pat) if p.is_file()]

    def rev(p):  # chromium-1243 -> 1243, 새 버전 먼저
        m = re.search(r"chromium-(\d+)", str(p))
        return int(m.group(1)) if m else 0
    return [str(p) for p in sorted(found, key=rev, reverse=True)]


def find_browser():
    env = os.environ.get("STUDY_BROWSER")
    if env and os.path.exists(env):
        return env
    for p in BROWSER_PATHS:
        if os.path.exists(p):
            return p
    for n in BROWSER_NAMES:
        p = shutil.which(n)
        if p:
            return p
    pw = playwright_browsers()
    if pw:
        return pw[0]
    sys.exit("Chromium 계열 브라우저를 찾지 못했다. 다음 중 하나를 한다:\n"
             "  1) 설치: pip install playwright && python -m playwright install chromium  (설치 뒤 자동으로 찾는다)\n"
             "  2) 이미 있는 Chrome/Edge 경로를 STUDY_BROWSER 환경변수에 넣는다\n"
             "  3) 둘 다 안 되면 PDF 대신 build.py --html-only로 만든 HTML을 브라우저에서 A4로 인쇄한다")


def inject_css(html):
    """study.css와 글꼴 경로, 꼬리말을 HTML에 넣는다."""
    css = (ASSETS / "study.css").read_text(encoding="utf-8")
    css = css.replace("url(fonts/", "url(" + (ASSETS / "fonts").as_uri() + "/")
    m = re.search(r'<meta\s+name="footer"\s+content="([^"]*)"', html)
    footer = htmlmod.unescape(m.group(1)) if m else ""
    css = css.replace("__FOOTER__", footer.replace("\\", "\\\\").replace('"', '\\"'))
    style = "<style>\n" + css + "\n</style>\n"
    return html.replace("</head>", style + "</head>", 1)


def needs_no_sandbox():
    # Linux에서 root로 돌리면 Chromium 샌드박스가 시작되지 않는다
    if os.environ.get("STUDY_NO_SANDBOX"):
        return True
    return sys.platform.startswith("linux") and hasattr(os, "geteuid") and os.geteuid() == 0


def print_pdf(browser, html_path: pathlib.Path, pdf_path: pathlib.Path):
    cmd = [
        browser, "--headless=new", "--disable-gpu", "--no-pdf-header-footer",
        "--print-to-pdf-no-header", "--virtual-time-budget=10000",
        "--print-to-pdf=" + str(pdf_path), html_path.as_uri(),
    ]
    if needs_no_sandbox():
        cmd.insert(1, "--no-sandbox")
    if pdf_path.exists():
        pdf_path.unlink()
    res = subprocess.run(cmd, capture_output=True, timeout=180)
    if not pdf_path.exists():
        err = (res.stderr or b"").decode("utf-8", "replace").strip().splitlines()[-8:]
        sys.exit("PDF 생성 실패: " + " ".join(cmd) + ("\n브라우저 오류 끝부분:\n  " + "\n  ".join(err) if err else ""))


# ── 글자 대비 ───────────────────────────────
def _lum(rgb):
    def ch(c):
        c = c / 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(c) for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = _lum(a), _lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def contrast_issues(page, pix, scale):
    """쪽의 글자마다 글자색과 실제 바탕색(렌더된 픽셀)의 대비를 잰다.
    기준: WCAG AA. 본문 4.5:1, 큰 글자(18pt 이상 또는 14pt 이상 굵은 글자) 3:1."""
    out = []
    W, H, n = pix.width, pix.height, pix.n
    data = pix.samples
    for b in page.get_text("dict")["blocks"]:
        for l in b.get("lines", []):
            for sp in l["spans"]:
                text = sp["text"].strip()
                if not text:
                    continue
                c = sp["color"]
                fg = ((c >> 16) & 255, (c >> 8) & 255, c & 255)
                x0, y0, x1, y1 = (int(v * scale) for v in sp["bbox"])
                x0, y0 = max(x0 - 2, 0), max(y0 - 2, 0)
                x1, y1 = min(x1 + 2, W - 1), min(y1 + 2, H - 1)
                counts = {}
                # 글자 상자 테두리 1px 띠에서 바탕색을 고른다 (글자 획은 피하고 가장 흔한 색)
                ring = [(x, y0) for x in range(x0, x1)] + [(x, y1) for x in range(x0, x1)] + \
                       [(x0, y) for y in range(y0, y1)] + [(x1, y) for y in range(y0, y1)]
                for x, y in ring:
                    i = (y * W + x) * n
                    px = tuple(data[i:i + 3])
                    if contrast(px, fg) < 1.15:
                        continue
                    counts[px] = counts.get(px, 0) + 1
                if not counts:
                    continue
                bg = max(counts, key=counts.get)
                ratio = contrast(fg, bg)
                bold = "Bold" in sp["font"] or "Semi" in sp["font"] or bool(sp["flags"] & 16)
                large = sp["size"] >= 18 or (bold and sp["size"] >= 14)  # PDF 글자 크기는 pt
                need = 3.0 if large else 4.5
                if ratio < need:
                    out.append((ratio, need, text[:24], "#%02x%02x%02x" % fg, "#%02x%02x%02x" % bg))
    return out


def inspect(pdf_path: pathlib.Path, preview_dir: pathlib.Path, dpi: int):
    fitz = load_fitz()
    if not fitz:
        print("점검 생략: PyMuPDF가 없다 (pip install pymupdf). PDF를 직접 열어 확인할 것.")
        return
    doc = fitz.open(str(pdf_path))
    preview_dir.mkdir(parents=True, exist_ok=True)
    fallback, low = {}, []
    print(f"페이지: {doc.page_count}")
    for i, page in enumerate(doc, 1):
        out = preview_dir / f"page-{i:02d}.png"
        pix = page.get_pixmap(dpi=dpi)
        pix.save(str(out))
        for ratio, need, txt, fg, bg in contrast_issues(page, pix, dpi / 72):
            low.append((i, ratio, need, txt, fg, bg))
        lines = [l for l in page.get_text().splitlines() if l.strip()]
        body = [l for l in lines if not re.fullmatch(r"\d+ / \d+", l.strip())]
        note = ""
        if i not in (1, doc.page_count) and len(body) < 10:
            note = "  <- 거의 빈 페이지: 카드나 블록이 다음 쪽으로 밀렸는지 확인"
        print(f"  {out}{note}")
        for b in page.get_text("rawdict")["blocks"]:
            for l in b.get("lines", []):
                for sp in l["spans"]:
                    name = sp["font"].split("+")[-1]
                    if name and not name.startswith(EXPECTED_FONTS):
                        chars = "".join(c["c"] for c in sp["chars"])
                        fallback.setdefault(name, set()).add((i, chars[:20]))
    if low:
        print(f"대비 부족: 글자 {len(low)}곳이 바탕과 구분이 약하다 (WCAG AA 기준). 글자색이나 바탕색을 바꿀 것:")
        for pg, ratio, need, txt, fg, bg in low[:20]:
            print(f"  p.{pg}  {ratio:.1f}:1 (필요 {need:.1f})  글자 {fg} / 바탕 {bg}  {txt!r}")
    else:
        print("대비: 모든 글자가 WCAG AA 기준을 넘는다")
    if fallback:
        print("대체 글꼴 사용 (SVG font-family에 Pretendard를 넣거나 기호를 바꿀 것):")
        for name, items in fallback.items():
            for pg, txt in sorted(items)[:8]:
                print(f"  {name}  p.{pg}  {txt!r}")
    else:
        print("글꼴: Pretendard / JetBrains Mono / Noto Serif KR만 사용")


def load_fitz():
    try:
        import pymupdf as fitz
        return fitz
    except ImportError:
        try:
            import fitz
            return fitz
        except ImportError:
            return None


# ── 차례 쪽 번호 ───────────────────────────────
TOC_ITEM = re.compile(r'(<a\s+href="#([\w-]+)"[^>]*>.*?<span\s+class="p">)(.*?)(</span>\s*</a>)', re.S)


def squash(t):
    return re.sub(r"\s+", "", htmlmod.unescape(re.sub(r"<[^>]+>", "", t)))


def toc_pages(html, pdf_path: pathlib.Path):
    """차례 항목마다 (id, 차례에 적힌 값, 실제 쪽)을 돌려준다. PyMuPDF가 없으면 None."""
    fitz = load_fitz()
    if not fitz:
        return None
    nav = re.search(r'<nav\s+class="toc".*?</nav>', html, re.S)
    if not nav:
        return []
    doc = fitz.open(str(pdf_path))
    # 1순위: Chrome이 PDF에 남긴 차례 링크. 링크마다 이동할 쪽이 정확히 들어 있다
    dest = {}
    for page in doc:
        for l in page.get_links():
            name = l.get("nameddest") or (l.get("uri") or "").lstrip("#")
            if name and l.get("page", -1) is not None and l.get("page", -1) >= 0:
                dest.setdefault(name, l["page"] + 1)
    # 2순위: 링크가 없으면 표지 다음 쪽부터 섹션 제목을 차례 순서대로 찾는다
    texts = [squash(p.get_text()) for p in doc]
    starts, pos = [], 0
    for t in texts:
        starts.append(pos)
        pos += len(t)
    full, cursor = "".join(texts), (starts[1] if len(starts) > 1 else 0)
    rows = []
    for m in TOC_ITEM.finditer(nav.group(0)):
        sid, shown = m.group(2), m.group(3).strip()
        actual = dest.get(sid)
        if actual is None:
            sec = re.search(r'<section[^>]*\bid="%s"[^>]*>.*?<h2[^>]*>(.*?)</h2>' % re.escape(sid), html, re.S)
            key = squash(sec.group(1)) if sec else ""
            hit = full.find(key, cursor) if key else -1
            if hit >= 0:
                cursor = hit + len(key)
                actual = max(i for i, st in enumerate(starts) if st <= hit) + 1
        rows.append((sid, shown, actual))
    return rows


def fix_toc(html, rows):
    want = {sid: str(actual) for sid, shown, actual in rows if actual and shown != str(actual)}

    def rep(m):
        return m.group(1) + want[m.group(2)] + m.group(4) if m.group(2) in want else m.group(0)
    nav = re.search(r'<nav\s+class="toc".*?</nav>', html, re.S)
    return html[:nav.start()] + TOC_ITEM.sub(rep, nav.group(0)) + html[nav.end():]


def orphan_heads(pdf_path: pathlib.Path):
    """섹션 제목(명조 15~19pt)이 쪽 끝에 홀로 남았는지 본다. 제목 아래에 리드 한두 줄밖에 없으면 경고."""
    fitz = load_fitz()
    if not fitz:
        return []
    bad = []
    doc = fitz.open(str(pdf_path))
    for i, page in enumerate(doc, 1):
        limit = page.rect.height - 15 * 72 / 25.4          # 꼬리말 영역 제외
        allspans, heads = [], []
        for b in page.get_text("dict")["blocks"]:
            for l in b.get("lines", []):
                for sp in l["spans"]:
                    if not sp["text"].strip() or sp["bbox"][3] > limit:
                        continue
                    allspans.append(sp)
                    if "Serif" in sp["font"] and 15 <= sp["size"] <= 19:
                        heads.append(sp)
        for h in heads:
            # 본문 칸(제목과 같은 왼쪽 선)에 있는 글자만 본다. 날개 메모는 세지 않는다
            below = [sp["bbox"][3] for sp in allspans if sp["bbox"][0] >= h["bbox"][0] - 2]
            if (max(below) - h["bbox"][3] < 40 and h["bbox"][1] > page.rect.height * 0.55
                    and i < doc.page_count):
                bad.append((i, h["text"].strip()))
    return bad


# ── 그림 점검 ───────────────────────────────
def figure_issues(figdir: pathlib.Path, used):
    """figures/의 SVG가 svg.md 규칙(폭 540, Pretendard, 크기 속성 없음)을 지키는지 본다."""
    out = []
    for fid in used:
        f = figdir / (fid + ".svg")
        if not f.exists():
            continue
        s = f.read_text(encoding="utf-8")
        root = re.search(r"<svg\b[^>]*>", s)
        if not root:
            out.append(f"{fid}.svg: <svg> 태그가 없다")
            continue
        r = root.group(0)
        vb = re.search(r'viewBox="\s*0\s+0\s+([\d.]+)\s+([\d.]+)"', r)
        if not vb:
            out.append(f"{fid}.svg: viewBox=\"0 0 540 H\"가 없다")
        elif abs(float(vb.group(1)) - 540) > 0.5:
            out.append(f"{fid}.svg: viewBox 폭이 {vb.group(1)}이다 (본문 그림은 540)")
        if re.search(r'\s(width|height)="', r):
            out.append(f"{fid}.svg: 루트에 width/height 속성을 넣지 않는다 (CSS가 100%로 맞춘다)")
        if "Pretendard" not in r:
            out.append(f"{fid}.svg: 루트 font-family에 Pretendard가 없다 (한글·화살표가 대체 글꼴로 찍힌다)")
        if re.search(r"<(image|foreignObject|script)\b", s):
            out.append(f"{fid}.svg: image/foreignObject/script는 쓰지 않는다")
    unused = sorted(p.stem for p in figdir.glob("*.svg") if p.stem not in used and p.stem != "cover") if figdir.is_dir() else []
    if unused:
        out.append("STUDY.md에서 쓰지 않는 그림 파일: " + ", ".join(unused))
    return out


def default_pdf(study: pathlib.Path, name: str):
    folder = study.parent.parent if study.parent.name == "_study" else study.parent
    return folder / (name + ".pdf")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("study", nargs="?", help="STUDY.md (study/2)")
    ap.add_argument("-o", "--out", help="PDF 경로 (기본: 단원 폴더에 N주차_공부자료(Topic).pdf)")
    ap.add_argument("--answers", choices=["inline", "appendix"], help="front matter의 answers보다 우선")
    ap.add_argument("--preview", help="미리보기 PNG 폴더 (기본: 임시 폴더)")
    ap.add_argument("--dpi", type=int, default=100)
    ap.add_argument("--html-only", action="store_true", help="PDF 없이 _study/sheet.html만 만든다")
    ap.add_argument("--check", action="store_true", help="브라우저를 찾아 경로만 출력한다 (못 찾으면 종료 코드 1)")
    a = ap.parse_args()

    if a.check:
        print(find_browser())
        return
    if not a.study:
        ap.error("STUDY.md를 지정하라 (또는 --check)")

    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
    import sheet

    study = pathlib.Path(a.study).resolve()
    figdir = study.parent / "figures"
    try:
        doc, info = sheet.build(study.read_text(encoding="utf-8"), figdir, a.answers)
    except sheet.FormatError as e:
        sys.exit(f"STUDY.md 형식 오류: {e}\n(course-study-builder의 check_study.py로 고친 뒤 다시 빌드한다)")
    for n in info["notes"]:
        print(n)
    print(f"구성: 섹션 {info['topics']}, 카드 {info['cards']}, 복습 {info['rows']}, 그림 {len(info['figures'])}")

    html_path = study.parent / "sheet.html"
    html_path.write_text(doc, encoding="utf-8")
    if a.html_only:
        built = study.parent / "sheet.print.html"
        built.write_text(inject_css(doc), encoding="utf-8")
        print(f"HTML: {built}  (브라우저에서 A4, 배경 그래픽 켜고 인쇄)")
        return

    pdf = pathlib.Path(a.out).resolve() if a.out else default_pdf(study, info["name"])
    browser = find_browser()
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="study_build_"))

    def render(html):
        built = tmp / "sheet.built.html"
        built.write_text(inject_css(html), encoding="utf-8")
        print_pdf(browser, built, pdf)

    render(doc)
    rows = toc_pages(doc, pdf)
    for _ in range(3):  # 쪽 번호를 고치면 줄바꿈이 달라질 수 있어 다시 확인한다
        if not (rows and any(act and shown != str(act) for _, shown, act in rows)):
            break
        doc = fix_toc(doc, rows)
        render(doc)
        rows = toc_pages(doc, pdf)
    html_path.write_text(doc, encoding="utf-8")
    shutil.rmtree(tmp, ignore_errors=True)
    print(f"PDF: {pdf}")

    # 점검
    if info["missing"]:
        print("그림 없음: 아래 그림을 figures/<id>.svg로 그려야 한다 (지금은 ASCII로 찍혔다)")
        for fid, cap in info["missing"]:
            print(f"  {fid}  {cap}")
    else:
        print("그림: 모두 있음" if info["figures"] else "그림: 없음")
    for w in figure_issues(figdir, info["figures"]):
        print("그림 규칙:", w)
    if rows is None:
        print("차례 점검 생략: PyMuPDF가 없다 (pip install pymupdf)")
    elif rows:
        bad = [(sid, shown, act) for sid, shown, act in rows if not act or shown != str(act)]
        if not bad:
            print("차례: 쪽 번호가 실제와 맞다")
        for sid, shown, act in bad:
            print(f"차례: #{sid} 차례 {shown!r}, 실제 {act if act else '찾지 못함'}")
    for pg, title in orphan_heads(pdf):
        print(f"쪽 끝 제목: {pg}쪽 '{title}' 아래에 본문이 없다 (앞 블록을 줄이거나 그림을 작게)")
    preview = pathlib.Path(a.preview).resolve() if a.preview else pathlib.Path(tempfile.gettempdir()) / f"{pdf.stem}_preview"
    inspect(pdf, preview, a.dpi)


if __name__ == "__main__":
    main()
