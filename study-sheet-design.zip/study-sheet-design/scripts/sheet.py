#!/usr/bin/env python3
"""STUDY.md (study/2) -> 조판용 HTML.

build.py가 불러 쓴다. 직접 실행하면 HTML만 만든다:
  python sheet.py _study/STUDY.md -o sheet.html

STUDY.md에 있는 것만 옮긴다. 쪽 번호, 실행 결과, 카드, 질문을 새로 만들지 않는다.
그림은 STUDY.md 옆 figures/<id>.svg를 넣는다. 아직 없으면 ASCII 원본을 그대로 찍고 missing에 남긴다.
표준 라이브러리만 쓴다.
"""
import argparse
import html
import pathlib
import re
import sys

SKILL = pathlib.Path(__file__).resolve().parent.parent
DEFS = SKILL / "assets" / "defs.svg"

# 과목 분야 -> 단원 강조색 (SKILL.md 원칙 1의 표)
ACCENTS = {
    "navy": "#2b44b8", "teal": "#0f6a64", "plum": "#7a2b5a", "ochre": "#8a4a0f",
}
SUBJECT_ACCENT = {
    **dict.fromkeys(["programming", "engineering", "math", "physics", "cs"], "navy"),
    **dict.fromkeys(["biology", "chemistry", "earth-science", "life-science"], "teal"),
    **dict.fromkeys(["humanities", "language", "arts", "history", "philosophy", "literature"], "plum"),
    **dict.fromkeys(["economics", "business", "social"], "ochre"),
}

PAL = {}


def set_palette(accent):
    h = accent.lstrip("#")
    if not re.fullmatch(r"[0-9a-fA-F]{6}", h):
        raise SystemExit("accent는 #2b44b8 같은 6자리 색이어야 한다: %r" % accent)
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))

    def mix(t, toward=255):
        return "#%02x%02x%02x" % tuple(round(c + (toward - c) * t) for c in (r, g, b))

    # 강조색은 흰 바탕의 글자와 흰 글자의 바탕으로 쓰인다. 흰색과 4.5:1이 안 되면 될 때까지 어둡게 한다
    def lum(rgb):
        f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
        return 0.2126 * f(rgb[0] / 255) + 0.7152 * f(rgb[1] / 255) + 0.0722 * f(rgb[2] / 255)
    orig = "#" + h.lower()
    k = 0
    while 1.05 / (lum((r, g, b)) + 0.05) < 4.5 and k < 40:
        r, g, b = (round(c * 0.92) for c in (r, g, b))
        k += 1
    acc = "#%02x%02x%02x" % (r, g, b)
    note = "" if acc == orig else "강조색 %s은 흰 바탕과 대비가 낮아 %s로 어둡게 바꿨다 (WCAG AA 4.5:1)" % (orig, acc)
    PAL.update(accent=acc, deep=mix(0.38, 0), tint=mix(0.91), tint2=mix(0.82))
    return note


LB = {
    "map": "한 장 요약", "toc": "차례", "range": "범위", "source": "출처", "verify": "검증",
    "oos": "시험범위 아님", "oos_short": "범위 밖", "warn": "주의", "note": "참고", "key": "핵심", "hint": "힌트",
    "add": "보충", "unverified": "미검증", "out": "실행 결과", "predict": "내 예측", "answer": "정답",
    "criterion": "판단 기준", "discuss": "토론형", "think": "생각해 보기", "review": "복습 질문",
    "think_lede": "예측을 먼저 적고, 막히면 힌트만 본 뒤, 직접 풀고 나서 점선 아래 정답과 비교한다.",
    "review_lede": "자습용이며 실제 시험 문제가 아니다. 오른쪽 단을 접어 가리고 풀고, 맞힌 문항은 네모에 표시한다.",
    "fold": "정답 (여기서 접기)", "q": "질문", "cards": "카드 {n}개", "rows": "{n}문항",
    "appendix": "부록: 생각해 보기 정답", "appendix_lede": "예측을 다 적은 뒤에 펼친다.",
    "answer_ref": "정답: 부록 A.{n}", "summary": "정리",
    "log": "복습 기록", "log_items": ["당일", "1주 뒤", "시험 전"],
    "verify_default": "자료의 관찰값", "verify_small": "실행 결과는 원본 그대로",
}

LONG_NOTE = 70   # 이보다 긴 주의·참고는 날개 대신 본문 칸에 둔다 (글자 수, 기호 제외)
CALLOUT = re.compile(r"^>\s*\[!(warn|key|note|hint|formula)\]\s*(.*)$")
_P1 = r"p\.\s?\d+(?:\s?[~–-]\s?\d+)?"
PAGE = re.compile(r"\((%s(?:,\s*%s)*)\)" % (_P1, _P1))   # (p.4) (p.2~3) (p.8, p.13)
OOS = re.compile(r"\[oos\]")
TAG = re.compile(r"^\[(map|summary|labs|think|review|oos)\]\s*")
MARKER = re.compile(r"^\[\[(/?)(predict|answer)\]\]$")
FIGURE = re.compile(r"^figure\s+([a-z0-9-]+)\s*(.*)$")
TREE_GLYPH = re.compile(r"^[\s│├└─┬┴┼|`\\+\-]*")


class FormatError(Exception):
    pass


# ── 인라인 ─────────────────────────────────────
def inline(s):
    parts = re.split(r"(`[^`]+`)", s)
    out = []
    for p in parts:
        if p.startswith("`") and p.endswith("`") and len(p) > 1:
            out.append("<code>" + html.escape(p[1:-1]) + "</code>")
        else:
            t = html.escape(p)
            t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
            out.append(t)
    return "".join(out)


def dash(s):  # p.1~4 -> p.1–4 (표시용; 숫자는 그대로)
    return re.sub(r"(p\.\s?\d+)\s?~\s?(\d+)", r"\1–\2", s)


def page_label(text):
    m = PAGE.search(text)
    if not m:
        return ""
    return re.sub(r"\s?[~–-]\s?", "–", re.sub(r"p\.\s", "p.", m.group(1)))


def strip_pages(text):
    t = PAGE.sub("", text).strip()
    return re.sub(r"\s+([.,:;!?])", r"\1", t)


# ── front matter ───────────────────────────────
def front_matter(md):
    lines = md.splitlines()
    if not lines or lines[0].strip() != "---":
        raise FormatError("첫 줄이 front matter(---)가 아니다. study/2 형식이 아니다")
    meta = {}
    for i in range(1, len(lines)):
        s = lines[i].strip()
        if s == "---":
            return meta, "\n".join(lines[i + 1:])
        if not s or s.startswith("#"):
            continue
        k, sep, v = s.partition(":")
        if not sep:
            raise FormatError("front matter %d행: 'key: value' 형식이 아니다: %r" % (i + 1, s))
        meta[k.strip()] = re.sub(r"\s+#\s.*$", "", v.strip())   # 끝의 " # 주석"만 뗀다 (#2b44b8 같은 값은 그대로)
    raise FormatError("front matter를 닫는 --- 가 없다")


# ── 블록 파서 ───────────────────────────────────
def parse_blocks(lines):
    """[(kind, data)] : p, table, code(lang, text), quote(kind, text|lines), list(ordered, items), h, marker"""
    blocks, i, n = [], 0, len(lines)
    while i < n:
        line = lines[i]
        s = line.strip()
        if not s:
            i += 1
            continue
        if s.startswith("```") or s.startswith("~~~"):
            fence, lang = s[:3], s[3:].strip()
            body = []
            i += 1
            while i < n and not lines[i].strip().startswith(fence):
                body.append(lines[i])
                i += 1
            blocks.append(("code", (lang, "\n".join(body))))
            i += 1
            continue
        m = MARKER.match(s)
        if m:
            blocks.append(("marker", (m.group(2), bool(m.group(1)))))
            i += 1
            continue
        if s.startswith("|"):
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                r = lines[i].strip()
                if not re.fullmatch(r"\|[\s:|-]+\|?", r):
                    rows.append([c.strip() for c in r.strip("|").split("|")])
                i += 1
            blocks.append(("table", rows))
            continue
        if s.startswith(">"):
            q = []
            while i < n and lines[i].strip().startswith(">"):
                q.append(lines[i].strip())
                i += 1
            m = CALLOUT.match(q[0])
            rest = [x.lstrip(">").strip() for x in q[1:]]
            if m and m.group(1) == "formula":
                rows = ([m.group(2)] if m.group(2) else []) + [x for x in rest if x]
                blocks.append(("quote", ("formula", rows)))
            elif m:
                blocks.append(("quote", (m.group(1), (m.group(2) + " " + " ".join(rest)).strip())))
            else:
                blocks.append(("quote", ("note", " ".join(x.lstrip(">").strip() for x in q))))
            continue
        if s.startswith("#"):
            blocks.append(("h", re.sub(r"^#+\s*", "", s)))
            i += 1
            continue
        m = re.match(r"^(\d+\.|-)\s+(.*)$", s)
        if m:
            ordered = m.group(1) != "-"
            items = []
            while i < n:
                mm = re.match(r"^\s*(\d+\.|-)\s+(.*)$", lines[i])
                if not mm:
                    break
                items.append(mm.group(2))
                i += 1
            blocks.append(("list", (ordered, items)))
            continue
        para = [s]
        i += 1
        while i < n and lines[i].strip() and not re.match(r"^\s*(```|~~~|\||>|#|\[\[|\d+\.\s|-\s)", lines[i]):
            para.append(lines[i].strip())
            i += 1
        blocks.append(("p", " ".join(para)))
    return blocks


def split_sections(md):
    secs, cur, in_fence = [], None, False
    for line in md.splitlines():
        if line.strip().startswith(("```", "~~~")):
            in_fence = not in_fence
        if not in_fence and line.startswith("## "):
            title = line[3:].strip()
            tag = TAG.match(title)
            kind = tag.group(1) if tag else "topic"
            cur = {"kind": "topic" if kind == "oos" else kind, "oos": kind == "oos",
                   "title": TAG.sub("", title).strip(), "lines": []}
            secs.append(cur)
        elif cur is not None:
            cur["lines"].append(line)
        elif line.strip():
            raise FormatError("front matter 뒤 첫 ## 앞에 내용이 있다: %r" % line.strip()[:40])
    return secs


# ── 렌더 조각 ───────────────────────────────────
class Ctx:
    """그림 폴더와 빠진 그림 목록"""
    def __init__(self, figdir):
        self.figdir = figdir
        self.missing = []
        self.used = []


def figure_html(fid, caption, ascii_, ctx):
    ctx.used.append(fid)
    svg = None
    if ctx.figdir:
        f = ctx.figdir / (fid + ".svg")
        if f.exists():
            svg = f.read_text(encoding="utf-8").strip()
            svg = re.sub(r"^<\?xml[^>]*>\s*", "", svg)
    if svg is None:
        ctx.missing.append((fid, caption))
        # 아직 그리지 않은 그림: ASCII 원본을 코드 블록으로 찍는다 (내용은 그대로 보인다)
        return "<pre>%s</pre>" % html.escape(ascii_)
    return '<figure><div class="label">%s</div>\n%s\n</figure>' % (inline(caption), svg)


def code_block(lang, text, ctx, in_answer=False):
    m = FIGURE.match(lang)
    if m:
        return figure_html(m.group(1), m.group(2), text, ctx)
    esc = html.escape(text)
    if lang == "out":
        if in_answer:
            return '<pre class="out">%s</pre>' % esc
        return ('<div><div class="label"><span class="tag ok">%s</span></div>\n<pre class="out">%s</pre></div>'
                % (LB["out"], esc))
    if text.lstrip().startswith("$ "):
        body = re.sub(r"(?m)^\$ ", '<span class="pr">$</span> ', esc)
        return '<pre class="term">%s</pre>' % body
    return "<pre>%s</pre>" % esc


def formula_html(rows):
    out, ex = [], ""
    for r in rows:
        if re.match(r"^(ex|예)\s*[:：]", r):
            ex = re.sub(r"^(ex|예)\s*[:：]\s*", "", r)
            continue
        lhs, sep, rhs = r.partition(" = ")
        if not sep:
            lhs, rhs = "", r
        out.append('<div class="row"><span class="lhs">%s</span><span class="eq">=</span>'
                   '<span class="rhs">%s</span></div>' % (inline(lhs), inline(rhs)))
    if ex:
        out.append('<p class="ex">%s</p>' % inline(ex))
    return '<div class="formula">\n  %s\n</div>' % "\n  ".join(out)


def table_bt(rows):
    if not rows:
        return ""
    head, body = rows[0], rows[1:]
    th = "".join("<th>%s</th>" % inline(c) for c in head)
    trs = []
    for r in body:
        tds = []
        for j, c in enumerate(r):
            cls = ' class="k"' if j == 0 and re.fullmatch(r"`[^`]+`", c) else ""
            val = c[1:-1] if cls else c
            tds.append("<td%s>%s</td>" % (cls, html.escape(val) if cls else inline(val)))
        trs.append("<tr>%s</tr>" % "".join(tds))
    return '<table class="bt">\n  <thead><tr>%s</tr></thead>\n  <tbody>\n    %s\n  </tbody>\n</table>' % (
        th, "\n    ".join(trs))


def list_html(ordered, items):
    tag = "ol" if ordered else "ul"
    return "<%s>%s</%s>" % (tag, "".join("<li>%s</li>" % inline(x) for x in items), tag)


def rail(notes):
    return '<aside class="rail">%s</aside>' % "".join('<div class="note">%s</div>' % n for n in notes)


def first_sentence(text):
    m = re.match(r"^(.+?[.!?。])(\s+|$)(.*)$", text)
    if m:
        return m.group(1), m.group(3).strip()
    return text, ""


def body_items(blocks, ctx):
    """섹션 본문: (날개 메모 묶음, 본문 블록) 순서. 날개 메모는 다음 본문 블록 바로 앞에 놓인다."""
    out, pending = [], []
    lede = None
    for kind, data in blocks:
        if kind == "quote":
            k, text = data
            if k == "formula":
                out.append((pending, formula_html(text)))
                pending = []
                continue
            plain = re.sub(r"[`*]", "", text)
            if k in ("warn", "note") and len(plain) > LONG_NOTE:
                # 긴 메모는 31mm 날개에서 세로로 늘어져 쪽을 넘긴다. 본문 칸에 머리말 문단으로 둔다
                tag = '<span class="tag %s">%s</span>' % ("warn" if k == "warn" else "link", LB["warn"] if k == "warn" else LB["note"])
                out.append((pending, '<p class="callout">%s%s</p>' % (tag, inline(text))))
                pending = []
                continue
            if k == "warn":
                pending.append('<span class="tag warn">%s</span>%s' % (LB["warn"], inline(text)))
            elif k == "note":
                pending.append('<span class="tag link">%s</span>%s' % (LB["note"], inline(text)))
            elif k == "key":
                out.append((pending, '<p><span class="tag link">%s</span>%s</p>' % (LB["key"], inline(text))))
                pending = []
            elif k == "hint":
                out.append((pending, '<p class="hint"><span class="tag">%s</span><span>%s</span></p>'
                            % (LB["hint"], inline(text))))
                pending = []
            continue
        if kind == "p":
            if lede is None:
                first, rest = first_sentence(data)
                lede = inline(first)
                if not rest:
                    continue
                data = rest
            if re.search(r"\(미검증", data):
                pending.append('<span class="tag add">%s</span>%s' % (LB["unverified"], "원본 표시 그대로"))
            if re.search(r"\(보충", data):
                pending.append('<span class="tag add">%s</span>%s' % (LB["add"], "강의자료 밖 내용"))
            html_ = "<p>%s</p>" % inline(data)
        elif kind == "table":
            html_ = "<div>\n%s\n</div>" % table_bt(data)
        elif kind == "code":
            html_ = code_block(data[0], data[1], ctx)
        elif kind == "list":
            html_ = list_html(*data)
        elif kind == "h":
            html_ = '<div class="label">%s</div>' % inline(data)
        else:
            continue
        out.append((pending, html_))
        pending = []
    if pending:
        # 섹션 끝에 남은 날개 메모는 마지막 본문 블록 옆에 붙인다
        if out:
            notes, last = out[-1]
            out[-1] = (notes + pending, last)
        else:
            out.append((pending, ""))
    return lede, out


# ── 카드 ─────────────────────────────────────
DISCUSS = re.compile(r"\s*\[discuss\]\s*")


def parse_card(head, lines, n):
    title = head
    discuss = bool(DISCUSS.search(title))
    pages = page_label(title)
    title = DISCUSS.sub(" ", strip_pages(title)).strip()
    pre, ans, mode = [], [], "pre"
    blocks = parse_blocks(lines)
    i = 0
    while i < len(blocks):
        b = blocks[i]
        if b[0] == "marker":
            name, closing = b[1]
            if name == "predict":
                if i + 1 < len(blocks) and blocks[i + 1][0] == "list":
                    pre.append(("ask", blocks[i + 1][1][1]))
                    i += 1
                pre.append(("write", None))
            elif closing:
                mode = "post"
            else:
                mode = "ans"
            i += 1
            continue
        (ans if mode == "ans" else pre).append(b)
        i += 1
    return {"no": str(n), "title": title, "pages": pages, "discuss": discuss, "pre": pre, "ans": ans}


def card_html(c, ctx, appendix_no=None):
    body = []
    for kind, data in c["pre"]:
        if kind == "write":
            body.append('<div><div class="label">%s</div><div class="write"><div></div><div></div></div></div>'
                        % LB["predict"])
        elif kind == "ask":
            body.append('<ol class="ask">%s</ol>' % "".join("<li><span>%s</span></li>" % inline(q) for q in data))
        elif kind == "quote" and data[0] == "hint":
            body.append('<p class="hint"><span class="tag">%s</span><span>%s</span></p>' % (LB["hint"], inline(data[1])))
        elif kind == "quote" and data[0] == "formula":
            body.append(formula_html(data[1]))
        elif kind == "quote":
            body.append("<p>%s</p>" % inline(data[1]))
        elif kind == "code":
            body.append(code_block(data[0], data[1], ctx))
        elif kind == "table":
            body.append(table_bt(data))
        elif kind == "list":
            body.append(list_html(*data))
        elif kind == "p":
            body.append("<p>%s</p>" % inline(data))
    ans = answer_html(c, ctx)
    if appendix_no is not None:
        body.append('<p class="answer-ref">%s</p>' % LB["answer_ref"].format(n=appendix_no))
        tail = ""
    else:
        tail = ('\n  <div class="cut"><span class="tag ok">%s</span></div>\n  %s'
                % (LB["criterion"] if c["discuss"] else LB["answer"], ans))
    no = c["no"] + ("<small>%s</small>" % LB["discuss"] if c["discuss"] else "")
    return ('<article class="card">\n  <div class="card-head"><div class="card-no">%s</div>'
            '<div class="card-title">%s</div><span class="pill">%s</span></div>\n'
            '  <div class="card-body">\n    %s\n  </div>%s\n</article>'
            % (no, inline(c["title"]), dash(c["pages"]), "\n    ".join(body), tail))


def answer_html(c, ctx):
    parts = []
    for i, (kind, data) in enumerate(c["ans"]):
        if kind == "p" and i == 0 and re.fullmatch(r"\*\*(.+)\*\*", data.strip()):
            parts.append('<p class="verdict">%s</p>' % inline(data.strip()[2:-2]))
        elif kind == "p":
            parts.append("<p>%s</p>" % inline(data))
        elif kind == "code":
            parts.append(code_block(data[0], data[1], ctx, in_answer=True))
        elif kind == "table":
            parts.append(table_bt(data))
        elif kind == "list":
            parts.append(list_html(*data))
        elif kind == "quote" and data[0] == "formula":
            parts.append(formula_html(data[1]))
        elif kind == "quote":
            parts.append("<p>%s</p>" % inline(data[1]))
    return '<div class="answer">\n    %s\n  </div>' % "\n    ".join(parts)


# ── 표지 맵 ─────────────────────────────────────
def map_svg(code):
    rows = []
    for line in code.splitlines():
        if not line.strip():
            continue
        prefix = TREE_GLYPH.match(line).group(0)
        depth = len(prefix) // 3 if prefix else 0
        text = line[len(prefix):].strip()
        oos = bool(OOS.search(text))
        text = OOS.sub("", text).strip()
        rows.append((depth, strip_pages(text), page_label(text), oos))
    if not rows:
        return ""
    kids = [r for r in rows[1:] if r[0] >= 1]
    if len(kids) > 8 and rows[0][0] == 0:
        return map_svg_two_col(rows[0], rows[1:])
    h = 30 * len(rows) + 4
    out = ['<svg viewBox="0 0 680 %d" font-family="Pretendard, \'Noto Sans KR\', sans-serif">' % h]
    for i, (d, text, pg, oos) in enumerate(rows):
        x, y = d * 26, 2 + i * 30
        w = 560 - x
        if oos:
            fill, stroke, ink, extra = "#fafbfc", "#8a8f99", "#474c56", ' stroke-dasharray="3 2"'
            text += " (%s)" % LB["oos"]
        elif d == 0:
            fill, stroke, ink, extra = PAL["tint2"], PAL["accent"], PAL["deep"], ""
        else:
            fill, stroke, ink, extra = PAL["tint"], PAL["accent"], PAL["deep"], ""
        if d > 0:
            out.append('<path d="M%d %d V%d H%d" fill="none" stroke="#8a8f99" stroke-width="0.8"/>'
                       % (x - 14, y - 6, y + 12, x))
        weight = ' font-weight="700"' if d == 0 else ""
        out.append('<rect x="%d" y="%d" width="%d" height="24" rx="3" fill="%s" stroke="%s"%s/>'
                   % (x, y, w, fill, stroke, extra))
        out.append('<text x="%d" y="%d" font-size="10.5" fill="%s"%s>%s</text>'
                   % (x + 10, y + 16, ink, weight, html.escape(text)))
        if pg:
            out.append('<text x="572" y="%d" font-size="9" fill="#5f6470" '
                       'font-family="Pretendard, sans-serif">%s</text>' % (y + 16, pg))
    out.append("</svg>")
    return "\n".join(out)


def map_svg_two_col(root, rows):
    """주제가 8개를 넘으면 뿌리를 위에 두고 나머지를 두 단으로 흘린다. 표지 한 쪽 안에 들어가게."""
    half = (len(rows) + 1) // 2
    cols = [rows[:half], rows[half:]]
    h = 34 + 26 * half + 4
    out = ['<svg viewBox="0 0 680 %d" font-family="Pretendard, \'Noto Sans KR\', sans-serif">' % h]
    d, text, pg, oos = root
    out.append('<rect x="0" y="2" width="680" height="24" rx="3" fill="%s" stroke="%s"/>' % (PAL["tint2"], PAL["accent"]))
    out.append('<text x="10" y="18" font-size="10.5" font-weight="700" fill="%s">%s</text>' % (PAL["deep"], html.escape(text)))
    if pg:
        out.append('<text x="670" y="18" font-size="9" fill="#4b515c" text-anchor="end">%s</text>' % pg)
    for c, col in enumerate(cols):
        x0 = c * 348
        for i, (d, text, pg, oos) in enumerate(col):
            x, y = x0 + 12 + (d - 1) * 14, 34 + i * 26
            w = 332 - (x - x0)
            if oos:
                fill, stroke, ink, extra = "#fafbfc", "#8a8f99", "#474c56", ' stroke-dasharray="3 2"'
                text += " (%s)" % LB["oos"]
            else:
                fill, stroke, ink, extra = PAL["tint"], PAL["accent"], PAL["deep"], ""
            out.append('<rect x="%d" y="%d" width="%d" height="21" rx="3" fill="%s" stroke="%s"%s/>' % (x, y, w, fill, stroke, extra))
            out.append('<text x="%d" y="%d" font-size="9.5" fill="%s">%s</text>' % (x + 8, y + 14.5, ink, html.escape(text)))
            if pg:
                out.append('<text x="%d" y="%d" font-size="8.5" fill="#5f6470" text-anchor="end">%s</text>' % (x + w - 7, y + 14.5, pg))
    out.append("</svg>")
    return "\n".join(out)


# ── 문서 ─────────────────────────────────────
def accent_of(meta):
    if meta.get("accent"):
        return meta["accent"]
    return ACCENTS[SUBJECT_ACCENT.get(meta.get("subject", "").lower(), "navy")]


def output_name(meta):
    name = "%s주차_공부자료(%s)" % (meta.get("unit", ""), meta.get("topic", ""))
    return re.sub(r'[\\/:*?"<>|]', "", name)


def build(md, figdir=None, answers=None):
    """STUDY.md 텍스트 -> (HTML, info). 형식이 틀리면 FormatError."""
    meta, rest = front_matter(md)
    for k in ("unit", "topic", "sources"):
        if not meta.get(k):
            raise FormatError("front matter에 %s가 없다" % k)
    notes = [n for n in [set_palette(accent_of(meta))] if n]
    ctx = Ctx(figdir)
    unit, topic = meta["unit"], meta["topic"]
    answers = answers or meta.get("answers", "inline")
    secs = split_sections(rest)

    topics, mapcode, think, review = [], "", None, None
    for s in secs:
        if s["kind"] == "map":
            mapcode = next((d[1] for k, d in parse_blocks(s["lines"]) if k == "code"), "")
        elif s["kind"] == "think":
            think = s
        elif s["kind"] == "review":
            review = s
        else:
            topics.append(s)

    cards = []
    if think:
        cur = None
        for line in think["lines"]:
            if line.startswith("### "):
                cur = {"head": line[4:].strip(), "lines": []}
                cards.append(cur)
            elif cur is not None:
                cur["lines"].append(line)
        cards = [parse_card(c["head"], c["lines"], i) for i, c in enumerate(cards, 1)]

    qa_rows = []
    if review:
        for k, d in parse_blocks(review["lines"]):
            if k == "table" and len(d) > 1:
                hdr = d[0]
                for r in d[1:]:
                    if len(hdr) >= 3 and re.fullmatch(r"#|No\.?|번호", hdr[0].strip(), re.I):
                        q, a = r[1], r[2] if len(r) > 2 else ""
                    else:
                        q, a = r[0], r[1] if len(r) > 1 else ""
                    qa_rows.append((q, a))
                break

    sec_html, toc = [], []
    num = 0
    for s in topics:
        title, oos, kind = s["title"], s["oos"], s["kind"]
        pages = page_label(title)
        clean = strip_pages(title)
        blocks = parse_blocks(s["lines"])
        num += 1
        sid = "s%02d" % num
        lede, items = body_items(blocks, ctx)
        if kind == "summary":
            src = LB["summary"]
        else:
            src = ("%s주 " % unit) + pages if pages else ""
        parts = ['<section class="sec" id="%s">' % sid,
                 '  <header class="head">',
                 '    <div class="badge"><span class="bn">%02d</span><span class="src">%s%s</span></div>'
                 % (num, html.escape(src), '<span class="oos">%s</span>' % LB["oos"] if oos else ""),
                 '    <div class="title"><h2>%s</h2>%s</div>' % (inline(clean), '<p class="lede">%s</p>' % lede if lede else ""),
                 "  </header>"]
        for nts, block in items:
            if nts:
                parts.append("  " + rail(nts))
            if block:
                parts.append(block)  # 들여쓰지 않는다: <pre> 안의 공백이 바뀐다
        parts.append("</section>")
        sec_html.append("\n".join(parts))
        toc.append((sid, "%02d" % num, clean, pages + (", " + LB["oos_short"] if oos else "") if kind != "summary" else ""))

    appendix = answers == "appendix"
    if cards:
        num += 1
        parts = ['<section class="sec" id="s%02d">' % num,
                 '  <header class="head">',
                 '    <div class="badge"><span class="bn">%02d</span><span class="src">%s</span></div>'
                 % (num, LB["cards"].format(n=len(cards))),
                 '    <div class="title"><h2>%s</h2><p class="lede">%s</p></div>' % (LB["think"], LB["think_lede"]),
                 "  </header>"]
        for i, c in enumerate(cards, 1):
            parts.append(card_html(c, ctx, i if appendix else None))
        parts.append("</section>")
        sec_html.append("\n".join(parts))
        toc.append(("s%02d" % num, "%02d" % num, LB["think"], LB["cards"].format(n=len(cards))))

    if qa_rows:
        rows = []
        for i, (q, a) in enumerate(qa_rows, 1):
            pg = page_label(a)
            a_txt = strip_pages(a).rstrip()
            rows.append('    <tr><td class="no"><span class="box"></span><span class="num">%02d</span></td>'
                        '<td class="q">%s</td><td class="a">%s%s</td></tr>'
                        % (i, inline(q), inline(a_txt), ' <span class="p">%s</span>' % pg if pg else ""))
        sec_html.append("\n".join([
            '<section class="sec" id="sQ">',
            '  <header class="head">',
            '    <div class="badge"><span class="bn">Q</span><span class="src">%s</span></div>' % LB["rows"].format(n=len(qa_rows)),
            '    <div class="title"><h2>%s</h2><p class="lede">%s</p></div>' % (LB["review"], LB["review_lede"]),
            "  </header>",
            '  <table class="qa">',
            '    <thead><tr><th></th><th>%s</th><th class="fold">%s</th></tr></thead>' % (LB["q"], LB["fold"]),
            "    <tbody>", "\n".join(rows), "    </tbody>", "  </table>", "</section>"]))
        toc.append(("sQ", "Q", LB["review"], LB["rows"].format(n=len(qa_rows))))

    if appendix and cards:
        parts = ['<section class="sec page-break appendix" id="sA">',
                 '  <header class="head">',
                 '    <div class="badge"><span class="bn">A</span><span class="src">%s</span></div>' % LB["answer"],
                 '    <div class="title"><h2>%s</h2><p class="lede">%s</p></div>' % (LB["appendix"], LB["appendix_lede"]),
                 "  </header>"]
        for i, c in enumerate(cards, 1):
            parts.append('  <div>\n    <div class="label">A.%d %s</div>\n    %s\n  </div>'
                         % (i, inline(c["title"]), answer_html(c, ctx)))
        parts.append("</section>")
        sec_html.append("\n".join(parts))
        toc.append(("sA", "A", LB["appendix"], ""))

    # 표지
    source = meta["sources"]
    verify = meta.get("env") or LB["verify_default"]
    srange = re.search(r"p\.\s?\d+\s?[~–-]\s?\d+", source)
    scope_range = dash(meta["scope"]) if meta.get("scope") else (page_label("(" + srange.group(0) + ")") if srange else "")
    oos_list = [page_label(s["title"]) for s in topics if s["oos"] and page_label(s["title"])]
    oos_range = ", ".join(oos_list)
    meta_rows = [
        (LB["range"], scope_range, (oos_range + " 제외") if oos_range else ""),
        (LB["source"], inline(dash(source)), ""),
        (LB["verify"], html.escape(verify), LB["verify_small"]),
    ]
    meta_html = "\n".join('    <div><dt>%s</dt><dd>%s<small>%s</small></dd></div>' % m for m in meta_rows)
    meta_html += '\n    <div class="log"><dt>%s</dt><dd>%s</dd></div>' % (
        LB["log"], "".join("<span>%s</span>" % x for x in LB["log_items"]))
    scope_note = meta.get("scope_note", "")
    scope_html = ('  <p class="scope"><span class="tag warn">%s</span>%s</p>'
                  % (LB["oos"] if oos_range else LB["warn"], inline(dash(scope_note))) if scope_note else "")
    toc_html = "\n".join(
        '    <a href="#%s"><span class="n">%s</span><span>%s</span><span class="s">%s</span><span class="p">–</span></a>'
        % (sid, n, inline(t), html.escape(dash(s))) for sid, n, t, s in toc)
    hero = ['  <div class="hero">',
            '    <div class="hero-top"><span>%s</span><span>%s</span></div>' % (html.escape(meta.get("course", "")),
                                                                              html.escape(meta.get("term", ""))),
            '    <div class="hero-num">%s</div>' % unit.zfill(2),
            "    <h1>%s</h1>" % inline(topic)]
    if meta.get("subtitle"):
        hero.append('    <p class="sub">%s</p>' % inline(meta["subtitle"]))
    motif = figdir / "cover.svg" if figdir else None
    if motif and motif.exists():
        svg = re.sub(r"^<\?xml[^>]*>\s*", "", motif.read_text(encoding="utf-8").strip())
        if 'class="motif"' not in svg[:200]:
            svg = svg.replace("<svg", '<svg class="motif"', 1)
        hero.append("    " + svg)
    hero.append("  </div>")
    cover = "\n".join(
        ['<section class="cover">'] + hero +
        ['  <dl class="meta">', meta_html, "  </dl>"] +
        ([scope_html] if scope_html else []) +
        ['  <figure class="map"><div class="label">%s</div>' % LB["map"],
         ("  " + map_svg(mapcode).replace("\n", "\n  ")) if mapcode else "",
         "  </figure>",
         '  <nav class="toc"><div class="label">%s</div>' % LB["toc"],
         toc_html,
         "  </nav>",
         "</section>"])
    footer = "%s주차  %s" % (unit, topic)
    try:
        defs = DEFS.read_text(encoding="utf-8").strip()
    except OSError:
        defs = ""
    doc = "\n".join([
        "<!doctype html>", '<html lang="ko">', "<head>", '<meta charset="utf-8">',
        "<title>%s주차 공부 자료 : %s</title>" % (html.escape(unit), html.escape(topic)),
        '<meta name="footer" content="%s">' % html.escape(footer),
        "</head>", "<body style='--unit: \"%s\"; --accent: %s; --accent-deep: %s; --accent-tint: %s'>"
        % (unit, PAL["accent"], PAL["deep"], PAL["tint"]),
        "<!-- build.py가 STUDY.md에서 만든 산출물. 손으로 고치지 않는다: 내용은 STUDY.md, 그림은 figures/ -->",
        defs, "", cover, "", "\n\n".join(sec_html), "</body>", "</html>", ""])
    info = {"topics": len(topics), "cards": len(cards), "rows": len(qa_rows), "notes": notes,
            "missing": ctx.missing, "figures": ctx.used, "name": output_name(meta)}
    return doc, info


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("study")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--answers", choices=["inline", "appendix"])
    a = ap.parse_args()
    src = pathlib.Path(a.study)
    try:
        doc, info = build(src.read_text(encoding="utf-8"), src.parent / "figures", a.answers)
    except FormatError as e:
        sys.exit("STUDY.md 형식 오류: %s" % e)
    pathlib.Path(a.out).write_text(doc, encoding="utf-8")
    print("HTML: %s  (섹션 %d, 카드 %d, 복습 %d)" % (a.out, info["topics"], info["cards"], info["rows"]))


if __name__ == "__main__":
    main()
