# End-to-end test: 7주차 예외 처리 (fictional course)

A complete input set for checking that the two skills turn class material into the finished study sheet. The lecture, labs and questions are made up for testing.

## Input (`input/`)

| File | Role (course-study-builder section 1) |
|---|---|
| `07-예외처리.pdf` | A. Lecture, 16 slides |
| `lab/ex1_divide.py`, `lab/ex2_parse.py`, `lab/ex3_score.py` | B. Practice code |
| `과제3_안내.md` | D. Open assignment (due 11/3) |
| `이전_질문.txt` | C. Earlier student questions with the answers given then |

Request: "7주차 공부자료 만들어줘. 시험은 14쪽까지."

## Traps the run must catch

- Slide 13 says finally does not run when try contains a return. Wrong: running it shows finally runs. The sheet marks it with `[!warn]` and shows the observed output.
- The 10/20 answer ("catching Exception for everything is safe") is wrong. The sheet corrects it, citing slide 13.
- The 10/22 answer is right and is kept.
- 과제 3 is open: concepts only, no solution.
- Exam scope p.1–14: p.15–16 become an `[oos]` section with no cards.
- `pdftotext -layout` scrambles the code on slides 4 to 6. Read with PyMuPDF.
- The unit folder plan is shown before any file is moved.

## Expected result

`expected/_study/STUDY.md` (study/2) and `expected/_study/figures/` are one correct output (Python 3.13.17). Another run may word things differently but should pass the same checks:

```
python3 <course>/scripts/check_study.py expected/_study/STUDY.md      # 0 errors, 0 warnings
python3 <design>/scripts/build.py expected/_study/STUDY.md --preview /tmp/e2e_preview
```

The build must print `그림: 모두 있음`, `차례: 쪽 번호가 실제와 맞다`, `대비: 모든 글자가 WCAG AA 기준을 넘는다`, `글꼴: Pretendard / JetBrains Mono / Noto Serif KR만 사용`, and no `그림 규칙:` or `쪽 끝 제목:` line. The cover shows 범위 p.1–14 with p.15–16 excluded. The reference build gives 14 pages.

Regression note: without `figures/` and `subtitle`, this STUDY.md renders pixel-identical to the v1 pipeline (scaffold.py + render.py) on the same content, except cards 2 and 8 and review 17, where multi-page references `(p.8, p.13)` now go to the page label as intended.
