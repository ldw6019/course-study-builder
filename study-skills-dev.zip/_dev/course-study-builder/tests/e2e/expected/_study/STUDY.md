---
format: study/2
course: 프로그래밍 기초 (파이썬)
term: 2026-2
unit: 7
topic: 예외 처리
subject: programming
subtitle: 처리할 수 있는 예외만, 구체적인 이름으로 잡는다
sources: `07-예외처리.pdf` p.1~16, 실습 `lab/ex1_divide.py`, `lab/ex2_parse.py`, `lab/ex3_score.py`, `과제3_안내.md`, 이전 질문 10/20, 10/22
scope: p.1~14
scope_note: 시험범위는 p.1~14다. p.15~16(예외 연결, with 문)은 `[시험범위 아님]`으로 따로 둔다.
env: Python 3.13.17
answers: inline
---

## [map]

```
예외 처리 (p.1~16)
├─ 오류의 두 종류와 traceback       (p.2~3)
├─ try / except와 여러 except       (p.4~6)
├─ else, finally, 실행 순서         (p.7~9)
├─ raise와 사용자 정의 예외         (p.10~11)
├─ 예외 계층과 흔한 실수            (p.12~13)
└─ [oos] 예외 연결과 with (p.15~16)
```

## 오류의 두 종류와 traceback (p.2~3)

**구문 오류**는 실행 전에, **예외**는 실행 중에 난다. 예외를 처리하지 않으면 프로그램이 멈추고 traceback이 찍힌다.

| 구분 | 언제 | 예 |
|---|---|---|
| 구문 오류(SyntaxError) | 실행 전, 해석기가 코드를 읽을 때 | 괄호 빠짐, 콜론 빠짐 |
| 예외(exception) | 실행 중 | `ZeroDivisionError`, `ValueError`, `IndexError`, `KeyError`, `FileNotFoundError` |

traceback은 아래에서부터 읽는다. 마지막 줄이 예외 이름과 메시지, 그 위가 호출 경로다 (p.3).

```out
ZeroDivisionError: division by zero
```

## try / except와 여러 except (p.4~6)

try 블록에서 예외가 나면 **그 줄 아래는 건너뛰고** 맞는 except로 간다. except는 위에서부터 처음 맞는 하나만 실행된다.

```
try:
    x = int(input("수: "))
    print(10 / x)
except ZeroDivisionError:
    print("0으로 나눌 수 없음")
```

| 쓰는 법 | 하는 일 | 쪽 |
|---|---|---|
| `except 예외이름:` | 그 예외(와 하위 예외)만 잡는다 | p.4 |
| except 여러 개 | 위에서부터 처음 맞는 것 하나만 실행 | p.5 |
| `except 예외이름 as e:` | 예외 객체를 `e`로 받는다. `print(e)`는 메시지를 찍는다 | p.6 |

```out
>>> try:
...     int("abc")
... except ValueError as e:
...     print("오류:", e)
...
오류: invalid literal for int() with base 10: 'abc'
```

> [!warn] 넓은 예외(`Exception`)를 위에 두면 아래의 구체적인 except에는 영영 도달하지 못한다. 구체적인 것부터 쓴다 (p.5). 생각 3에서 직접 확인한다.

> [!note] 10/20 질문 "except Exception으로 다 잡아 두면 안전한가?" 당시 답변은 "웬만하면 Exception으로 다 잡는 게 안전하다"였는데 **틀렸다**. 넓게 잡으면 오타 같은 진짜 버그까지 삼켜서 원인을 찾기 어려워진다(p.13, 생각 5). 처리할 수 있는 예외만 구체적으로 잡는다.

## else, finally, 실행 순서 (p.7~9)

**else**는 예외가 없을 때만, **finally**는 예외가 나든 안 나든 항상 실행된다.

```figure flow try / except / else / finally 실행 흐름
try → (예외?) ──아니오──→ else ──→ finally
         │
         예 ──→ 맞는 except ──→ finally
         │
         맞는 except 없음 ──→ finally ──→ 예외가 밖으로
```

| 상황 | 실행되는 블록 (p.9) |
|---|---|
| 예외 없음 | try → else → finally |
| 예외, 맞는 except 있음 | try(일부) → except → finally |
| 예외, 맞는 except 없음 | try(일부) → finally → 예외가 밖으로 |

실습 7-1은 네 블록을 모두 쓴다. 실행 결과 (Python 3.13.17):

```out
계산 성공
divide 끝
5.0
0으로 나눌 수 없습니다
divide 끝
None
```

> [!note] 10/22 질문 "else 절은 왜 있나?" 당시 답변이 맞다. try 블록을 짧게 두면 except가 엉뚱한 줄의 예외까지 잡지 않는다. else에는 "성공했을 때만 할 일"을 둔다.

## raise와 사용자 정의 예외 (p.10~11)

**raise**로 예외를 직접 일으키고, `Exception`을 상속해 내 예외를 만든다.

```
class ScoreError(Exception):
    pass

def check(score):
    if not 0 <= score <= 100:
        raise ScoreError(f"점수 범위 밖: {score}")
    return score
```

| 문장 | 하는 일 | 쪽 |
|---|---|---|
| `raise ValueError("메시지")` | 예외를 새로 일으킨다 | p.10 |
| except 안의 `raise` (이름 없이) | 받은 예외를 그대로 다시 던진다 | p.10 |
| `class 이름Error(Exception)` | 사용자 정의 예외. 이름은 Error로 끝내는 관례 | p.11 |

실습 7-3 실행 결과:

```out
통과: 90
오류: 점수 범위 밖: 105
오류: 점수 범위 밖: -1
```

## 예외 계층과 흔한 실수 (p.12~13)

예외는 **계층**을 이룬다. `except 상위예외`는 그 아래 예외를 모두 잡는다.

```figure hierarchy 예외 계층 (일부)
BaseException
├─ KeyboardInterrupt
├─ SystemExit
└─ Exception
   ├─ ArithmeticError
   │  └─ ZeroDivisionError
   ├─ LookupError
   │  ├─ IndexError
   │  └─ KeyError
   └─ ValueError
```

```out
>>> issubclass(KeyboardInterrupt, Exception), issubclass(KeyboardInterrupt, BaseException)
(False, True)
>>> issubclass(ZeroDivisionError, ArithmeticError), issubclass(KeyError, LookupError)
(True, True)
```

| 흔한 실수 (p.13) | 왜 나쁜가 |
|---|---|
| `except:` (이름 없음) | 모든 예외를 삼켜 버그를 숨긴다 |
| `except Exception: pass` | 무엇이 실패했는지 알 수 없다 |
| 너무 긴 try 블록 | 어느 줄에서 났는지 모른다 |

> [!warn] 슬라이드 p.13의 "finally는 try 안에 return이 있으면 실행되지 않는다"는 **틀렸다**. return이 있어도 finally는 실행된다. Python 3.13.17에서 확인했다(생각 2). p.8의 "finally는 항상 실행된다"가 맞다.

## [oos] 예외 연결과 with (p.15~16)

`raise 새예외 from 원래예외`는 원래 예외를 `__cause__`로 남긴다 (p.15). `with open(...) as f:`는 블록을 나갈 때 예외가 나도 파일을 닫아 finally와 같은 효과를 낸다 (p.16).

```out
ValueError | invalid literal for int() with base 10: 'x'
```

## [summary] 정리 : 예외 처리 핵심 모음

| 블록·문장 | 언제 실행·쓰임 |
|---|---|
| `try` | 예외가 날 수 있는 코드 |
| `except 예외` | 그 예외가 났을 때 |
| `else` | 예외가 없었을 때만 |
| `finally` | 항상 (return이 있어도) |
| `raise 예외(...)` | 직접 일으킬 때 |
| `raise` (except 안) | 받은 예외를 다시 던질 때 |
| `class XError(Exception)` | 내 예외를 만들 때 |

| 예외 | 흔한 원인 |
|---|---|
| `ZeroDivisionError` | 0으로 나눔 |
| `ValueError` | 값의 형식이 틀림 (`int("abc")`) |
| `IndexError` / `KeyError` | 없는 위치 / 없는 키 |
| `FileNotFoundError` | 없는 파일을 엶 |

## [labs] 실습 자료 현황

| 항목 | 관련 쪽 | 상태 |
|---|---|---|
| `ex1_divide.py` 나눗셈 계산기 | p.7~9 | 실행 확인. try, except, else, finally를 모두 씀 |
| `ex2_parse.py` 정수 목록 읽기 | p.6 | 실행 확인. 결과 `[3, 10]` |
| `ex3_score.py` 사용자 정의 예외 | p.11 | 실행 확인. 슬라이드 p.11과 같은 `ScoreError` |
| 과제 3 성적 파일 읽기 | p.4~11 | 진행 중(마감 11/3). 개념만 정리하고 풀이는 쓰지 않는다 |

## [think]

### divide(1, 0)의 출력 순서 (p.7~9)

```
def divide(a, b):
    try:
        result = a / b
    except ZeroDivisionError:
        print("0으로 나눌 수 없습니다")
        return None
    else:
        print("계산 성공")
        return result
    finally:
        print("divide 끝")

print(divide(1, 0))
```

[[predict]]
- 몇 줄이 어떤 순서로 찍힐까?
- except 안의 return 다음에도 무언가 실행될까?

> [!hint] p.9의 표에서 "예외, 맞는 except 있음" 줄을 보자.

[[answer]]
**"0으로 나눌 수 없습니다", "divide 끝", "None" 순서로 세 줄이 찍힌다.**

```out
0으로 나눌 수 없습니다
divide 끝
None
```

except의 return이 함수를 끝내기 전에 finally가 먼저 실행된다. 그래서 "divide 끝"이 `None`보다 먼저 나온다. else는 예외가 났으므로 건너뛴다.
[[/answer]]

### return이 있어도 finally가 돌까 (p.8, p.13)

```
def f():
    try:
        return "try의 return"
    finally:
        print("finally 실행됨")

print(f())
```

[[predict]]
- "finally 실행됨"이 찍힐까?
- 찍힌다면 return 값보다 먼저일까?
- 나중일까?

> [!hint] p.8과 p.13이 서로 다른 말을 한다. 어느 쪽이 맞는지는 실행해 봐야 안다.

[[answer]]
**찍힌다. "finally 실행됨"이 먼저, 그다음 return 값이 찍힌다.**

```out
finally 실행됨
try의 return
```

슬라이드 p.13의 "return이 있으면 finally가 실행되지 않는다"는 틀렸다. 함수가 값을 돌려주기 직전에 finally가 실행된다. 그래서 파일 닫기 같은 정리 코드를 finally에 두면 return이 있어도 안전하다.
[[/answer]]

### except 순서를 바꾸면 (p.5)

```
try:
    1/0
except Exception:
    print("Exception이 먼저 잡음")
except ZeroDivisionError:
    print("도달 못 함")
```

[[predict]]
- 어느 줄이 찍힐까?
- 아래 except는 언제 쓰일까?

> [!hint] p.12의 계층에서 `ZeroDivisionError`가 `Exception` 아래에 있는지 보자.

[[answer]]
**"Exception이 먼저 잡음"만 찍힌다. 아래 except는 영영 쓰이지 않는다.**

```out
Exception이 먼저 잡음
```

except는 위에서부터 처음 맞는 하나만 실행된다. `ZeroDivisionError`는 `Exception`의 하위 예외라서 첫 except가 먼저 잡는다. 그래서 구체적인 예외를 위에 써야 한다 (p.5).
[[/answer]]

### "4.5"는 왜 건너뛰나 (p.6)

```
def parse_all(items):
    nums = []
    for s in items:
        try:
            nums.append(int(s))
        except ValueError as e:
            print("건너뜀:", e)
    return nums

print(parse_all(["3", "x", "10", "4.5"]))
```

[[predict]]
- 어떤 값이 건너뛰어지고 결과 리스트는 무엇일까?
- `"4.5"`는 숫자인데 왜 문제가 될까?

> [!hint] `int()`가 받아들이는 문자열의 모양을 떠올려 보자.

[[answer]]
**`"x"`와 `"4.5"`가 건너뛰어지고 결과는 `[3, 10]`이다.**

```out
건너뜀: invalid literal for int() with base 10: 'x'
건너뜀: invalid literal for int() with base 10: '4.5'
[3, 10]
```

`int()`는 정수 모양 문자열만 받는다. 소수 모양 문자열은 `ValueError`다. 소수를 정수로 만들려면 `int(float("4.5"))`처럼 두 번 바꾸면 `4`가 된다. 예외 하나가 반복 전체를 멈추지 않는 이유는 try가 반복문 안쪽에 있기 때문이다.
[[/answer]]

### 빈 except가 숨기는 버그 (p.13)

```
def to_int(s):
    try:
        return int(s.strip())
    except:
        print("변환 실패:", s)

print(to_int(" 42 "))
print(to_int(42))
```

[[predict]]
- 두 호출은 각각 무엇을 찍을까?
- 두 번째 호출의 진짜 문제는 무엇일까?

> [!hint] 정수 `42`에 `.strip()`이 있는지 생각해 보자.

[[answer]]
**첫 호출은 `42`, 두 번째는 "변환 실패: 42"와 `None`을 찍는다. 진짜 원인은 숫자를 넘긴 호출 쪽 버그인데 가려졌다.**

```out
42
변환 실패: 42
None
```

정수에는 `strip`이 없어서 `AttributeError`가 난다. 그런데 이름 없는 `except:`가 그것까지 삼켜 "변환 실패"라는 엉뚱한 말을 찍는다. `except ValueError:`로 좁히면 이 버그는 `AttributeError: 'int' object has no attribute 'strip'`로 드러난다.
[[/answer]]

### except 안에서 raise만 쓰면 (p.10)

```
def load(n):
    try:
        return 10 / n
    except ZeroDivisionError:
        print("load: 기록만 남김")
        raise

try:
    load(0)
except ZeroDivisionError as e:
    print("호출한 쪽:", type(e).__name__, e)
```

[[predict]]
- 몇 줄이 찍힐까?
- 호출한 쪽이 받는 예외는 무엇일까?

> [!hint] 이름 없는 `raise`는 "받은 그것을 다시"라는 뜻이다 (p.10).

[[answer]]
**두 줄이 찍힌다. 호출한 쪽은 원래의 `ZeroDivisionError`를 그대로 받는다.**

```out
load: 기록만 남김
호출한 쪽: ZeroDivisionError division by zero
```

안쪽에서 기록만 하고 처리는 바깥에 맡기는 형태다. 예외를 삼키지 않으면서 중간에서 할 일을 할 수 있다.
[[/answer]]

### Ctrl+C와 except Exception (p.12)

```
try:
    try:
        raise KeyboardInterrupt
    except Exception:
        print("Exception이 잡음")
except BaseException as e:
    print("바깥까지 나감:", type(e).__name__)
```

[[predict]]
- 안쪽 except가 잡을까?
- 바깥까지 나갈까?

> [!hint] p.12의 계층에서 `KeyboardInterrupt`가 어디에 붙어 있는지 보자.

[[answer]]
**바깥까지 나간다. "바깥까지 나감: KeyboardInterrupt"가 찍힌다.**

```out
바깥까지 나감: KeyboardInterrupt
```

`KeyboardInterrupt`는 `Exception`이 아니라 `BaseException` 바로 아래에 있다. 그래서 `except Exception`으로 넓게 잡아도 Ctrl+C로 프로그램을 멈출 수 있다. 실제 Ctrl+C 대신 `raise KeyboardInterrupt`로 같은 예외를 일으켜 확인했다.
[[/answer]]

### 어디까지 잡을까 (p.5, p.13) [discuss]

파일에서 숫자를 읽어 평균을 내는 함수를 만든다. 파일이 없을 수도 있고, 어떤 줄은 숫자가 아닐 수도 있다. 이 함수는 여러 프로그램이 함께 쓴다.

[[predict]]
- 예외를 어디서, 어떤 이름으로 잡을까?
- 넓게 잡을 때와 좁게 잡을 때 무엇이 달라질까?

> [!hint] "이 자리에서 처리할 수 있는 예외인가"를 기준으로 나눠 보자.

[[answer]]
**기준은 "그 자리에서 의미 있게 처리할 수 있는가"다. 처리할 수 있는 예외만 구체적인 이름으로 잡고, 나머지는 위로 올려 보낸다.**

| 선택지 | 맞는 경우 | 비용 |
|---|---|---|
| 줄마다 `except ValueError`로 건너뛰기 | 숫자 아닌 줄이 가끔 섞여도 계속 가야 할 때 | 건너뛴 줄을 알리지 않으면 데이터 문제를 놓친다 |
| `FileNotFoundError`는 잡지 않고 위로 | 파일 경로를 고칠 사람이 호출한 쪽일 때 | 호출한 쪽마다 처리해야 한다 |
| `except Exception`으로 한 번에 | 거의 없음 | 오타 같은 버그까지 숨긴다 (생각 5) |

자료는 "구체적인 예외부터, 필요한 만큼만 잡는다"까지 말한다 (p.13~14). 어디서 처리할지는 프로그램 구조에 따라 열려 있다. 과제 3의 조건과 겹치므로 과제 풀이는 직접 정한다.
[[/answer]]

## [review]

| Q | A |
|---|---|
| 구문 오류와 예외는 언제 생기나? | 구문 오류는 실행 전, 예외는 실행 중에 생긴다 (p.2). |
| traceback의 마지막 줄에는 무엇이 있나? | 예외 이름과 메시지 (p.3). |
| try 블록에서 예외가 나면 그 아래 줄은? | 건너뛰고 맞는 except로 간다 (p.4). |
| except가 여러 개면 몇 개가 실행되나? | 위에서부터 처음 맞는 하나만 (p.5). |
| except를 쓸 때 어떤 순서로 적나? | 구체적인 예외부터, 넓은 예외는 아래에 (p.5). |
| `except ValueError as e`에서 `e`는? | 예외 객체. `print(e)`는 메시지를 찍는다 (p.6). |
| `int("abc")`가 내는 예외는? | `ValueError` (p.6). |
| else 절은 언제 실행되나? | try에서 예외가 없을 때만 (p.7). |
| finally 절은 언제 실행되나? | 예외가 나든 안 나든 항상, return이 있어도 (p.8). |
| 예외가 났는데 맞는 except가 없으면? | finally를 실행한 뒤 예외가 밖으로 나간다 (p.9). |
| 함수 안에서 직접 예외를 일으키는 문장은? | `raise 예외(메시지)` (p.10). |
| except 안에서 이름 없이 `raise`만 쓰면? | 받은 예외를 다시 던진다 (p.10). |
| 사용자 정의 예외는 무엇을 상속하나? | `Exception` (p.11). |
| `except Exception`은 Ctrl+C를 잡나? | 잡지 않는다. `KeyboardInterrupt`는 `Exception` 밖에 있다 (p.12). |
| `except ArithmeticError`는 0으로 나누기를 잡나? | 잡는다. `ZeroDivisionError`가 그 아래다 (p.12). |
| 이름 없는 `except:`가 나쁜 이유는? | 모든 예외를 삼켜 버그를 숨긴다 (p.13). |
| 슬라이드 p.13의 finally 설명에서 틀린 점은? | return이 있어도 finally는 실행된다 (p.8, p.13). |
| 실습 7-2에서 `"4.5"`가 건너뛰어진 이유는? | `int("4.5")`는 `ValueError`를 내기 때문이다 (p.6). |
