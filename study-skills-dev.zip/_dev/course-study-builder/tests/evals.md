# Evaluation scenarios

Run each once without the skills (baseline) and once with them, and compare. Scenarios 1–6 exercise course-study-builder, 7–9 study-sheet-design, 10 both.

## 1. Lecture only

Input: one text lecture PDF (~30 slides). No B, C, D.
- At most one short question; the report says B, C, D did not exist.
- No `[labs]` section. Every topic heading and map line has a page reference.
- `check_study.py`: 0 errors.

## 2. Exam scope given

Input: lecture PDF plus "시험은 41쪽까지만 나와."
- Front matter `scope: p.1~41` and a `scope_note`.
- The part after p.41 is an `[oos]` section; no cards for it.
- The scope is recorded where the next session will see it.

## 3. Open assignment with code

Input: lecture PDF, lab folder, an assignment guide whose solution is still open.
- Example code runs in a throwaway directory; real output in `out` blocks.
- Anything not run is marked `(미검증, …)`. The assignment is explained, not solved.
- The student's files are untouched; temporary files deleted.

## 4. Folder organization

Input: a unit folder with slides, labs and an assignment mixed at the top level.
- A move plan (current → new) is shown and nothing moves before the OK.
- After the OK: files are in 강의/ 실습/ 과제/ 메모/, nothing deleted or overwritten, names unchanged.
- Unattended run: nothing moves; the plan is in the report.

## 5. Exam signals and past exam style

Input: a transcript where the lecturer says "이 부분은 시험에 낸다" at p.23, plus last year's exam with 단답형 and 출력 예측.
- p.23 carries `[!key]` with the page; a card or question covers it.
- No other topic is labelled exam-likely in the sheet.
- Review questions use 단답형 and 출력 예측 forms; no past question is copied.

## 6. Language

Input: an English-only lecture, request in Korean.
- All printed text in STUDY.md is Korean; code, commands and error messages unchanged.
- Tags, markers and front matter keys are the English tokens from format.md.

## 7. Design build (figures)

Input: a valid STUDY.md with two `figure` blocks, no `figures/` folder.
- First build lists both ids under `그림 없음:`.
- After drawing: `그림: 모두 있음`, no `그림 규칙:` line, figure labels and numbers match the figure blocks, `sheet.html` untouched by hand.

## 8. Design build unavailable

Input: as 7 with no Chromium-family browser.
- One install attempt, then `--html-only` and a one-line note. No question to the student.

## 9. Legibility

Input: front matter `accent: #ffd600`.
- build darkens the accent and says so; `대비: 모든 글자가 WCAG AA 기준을 넘는다`.

## 10. Full run on `tests/e2e`

Every item in `tests/e2e/README.md` under "Traps" and "Expected result".
